Reunião de Definição de Produto e Estratégia – Análise de Dados de Câmeras Urbanas
Visão Geral
Reunião focada em discutir a viabilidade, os desafios legais e a definição do produto relacionado ao uso de imagens de câmeras urbanas para análise e solução de problemas de mobilidade, segurança e gestão urbana. O grupo debateu desde questões de legislação até detalhes técnicos e estratégicos do produto, enfatizando a inovação, o uso de dados existentes e a necessidade de respostas claras para potenciais clientes.
Palavras-chave: Análise de Dados, Câmeras Urbanas, Produto Inovador
Principais Pontos
Questões Legais: Mudanças legislativas são necessárias para priorizar ônibus no trânsito, reconhecendo sua importância como serviço essencial.
Definição do Produto: Produto inovador baseado na análise de imagens de câmeras já instaladas, combinando software e consultoria especializada.
Inovação e Execução: Uso de dados existentes para entregar insights valiosos, com estratégia de piloto rápido para validação prática.
Próximos Passos: Alinhar discurso da equipe, preparar respostas para dúvidas dos clientes e realizar simulações para comprovar eficácia.
Principais Temas Abordados
Questões Legais e Legislação
Discussão sobre a necessidade de alterar leis para priorizar ônibus no trânsito, já que atualmente eles não têm prioridade, apesar de serem serviço essencial.
Esclarecimento sobre diferenças entre transporte obrigatório, essencial e prioritário, com menção à legislação federal.
Reconhecimento de que mudanças para priorizar ônibus exigiriam aprovação legislativa.
Definição do Produto e Proposta de Valor
Debate sobre se o foco é produto, solução, ferramenta ou consultoria.
Consenso de que a proposta é criar um produto inovador baseado na análise de imagens de câmeras já instaladas na cidade, evitando custos com novas instalações.
O produto engloba software próprio e consultoria especializada para tratamento e interpretação dos dados.
Exemplo citado: análise de imagens para identificar causas de acidentes, como o tipo de veículo envolvido (ex: caminhonetes) e padrões de comportamento.
Inovação e Diferenciais
A inovação está em utilizar dados já disponíveis (câmeras existentes) e entregar insights valiosos, ao invés de apenas coletar dados brutos.
Produto validado por experiências e simulações já realizadas.
Importância de agregar diferentes perspectivas para enriquecer a análise, como experiências de diferentes áreas da cidade.
Execução e Estratégia
Estratégia de entregar um piloto rápido, utilizando dados reais para simular e demonstrar o funcionamento do produto.
Exemplo ilustrativo: análise detalhada de comportamento de um cachorro registrado por câmeras, mostrando o nível de granularidade dos dados possíveis.
Discussão sobre a necessidade de respostas objetivas aos clientes, reduzindo dúvidas e tendo clareza sobre onde encontrar respostas nos dados.
Monetização e Contratos
Por ora, foco na definição do produto, deixando a monetização para um momento posterior.
Preocupação com contratos e propriedade intelectual do software desenvolvido.
Exemplos e Situações Práticas
Análise de Acidentes: Identificação de padrões, como aumento de acidentes quando caminhonetes param fora do local permitido.
Uso de Câmeras Existentes: Proposta de utilizar as 700 câmeras já instaladas na cidade, superando desafios como câmeras inativas.
Demonstração de Piloto: Possibilidade de simular o sistema em minutos, mostrando o potencial do produto em tempo real.
Granularidade dos Dados: Exemplo do cachorro amarelo, mostrando como o sistema pode captar detalhes minuciosos do ambiente urbano.
Próximos Passos e Recomendações
Foco e Clareza: Manter o discurso alinhado entre todos os membros da equipe para apresentar o produto de forma coesa.
Preparação para Perguntas: Antecipar dúvidas dos clientes e preparar respostas claras, baseando-se nos dados disponíveis.
Piloto e Validação: Realizar simulações práticas para comprovar a eficácia do produto antes de avançar para contratos e monetização.

Resumo Final: A reunião consolidou a proposta de um produto inovador de análise de dados urbanos utilizando câmeras já existentes, com foco em consultoria e entrega de insights valiosos para gestão urbana. Foram discutidos desafios legais, a importância de clareza na comunicação e a necessidade de validação prática do produto.

Transcription
00:00
Declaração por quê? Legislação. Lei, aprovação. Discussão. Você tem que passar em venda, tem que passar— E, assim, essa questão era o último tópico dos não apresentáveis. Mas por que tem que mudar a lei?
00:14
Uai, porque vai alterar porque o ônibus não é prioritário hoje, nunca foi. Muda a prioridade, não. Você, na verdade, é ser trans, é lei federal. Você vai ter que liberar. Isso é lei federal, sem você— Se a pessoa passar onde não é federal. Eu tô falando que é ruim, não.
00:29
Eu tô falando que é ruim, não. Eu só queria entender o que você entendeu que talvez eu falei errado. Isso daí, isso daí pode ser uma ideia que pode chegar mesmo depois. Tudo bem. Mas pra esse negócio aqui, hoje, ele não passa.
00:41
Porque não tá nos critérios. Você fala do— Porque vai mudar a lei. Do semáforo, entender que tem um ônibus vindo e abre, e ter preferência pra ele. É. Hoje isso aí, o direito de ele vira pra todos, não é só pro ônibus.
00:53
Porque quem tá de carro também tá com direito de ir também. Entendeu? Só que tá na Constituição que transporte público ele é obrigatório, ele é essencial. Obrigatório, mas ele não é, não é essencial. Essencial, sim. Mercencial.
01:08
Não, não, ele é essencial, ele não é prioritário. É. Não é mercencial, ele não é emergência. Ele é pro— Não é emergência. Ela falou que— você viu aquela pirâmide? Uhum. Veículo particular, certo, aí você— É o
01:20
É o que mais consome, tudo. Isso, é o, né, é na pirâmide lá, é o que tem mais, porém é o menos, né, vamos dizer assim, é o segundo lá, não sei qual que é. Vamos voltar? Ônibus, só tá acima de todos os veículos automotivos.
01:32
Automotores. Pessoal não tá acima de gente que anda a pé. Entendeu? Tá, velho. Ou vão devolver, vão usar aí, aguenta aí, vamos definir, vamos, vamos tentar definir se a gente vai mexer com produto, solução, ferramenta, consultoria.
01:48
É porque sim. Solução com consultoria, se é— É porque sim, eu acho. Sim. E se a gente, se a gente, vamos supor, o Hackathon, vai ganhar quem? Inovar. Com a ideia da gente fazer o tratamento das imagens do aparato de CCTV que já existe dentro de quatro semanas hoje, a gente entrega uma ferramenta, uma ferramenta inovadora, né, de tomada de decisões.
02:16
Sim. E aí a gente é lento em tudo que a gente vai conseguir extrair daquilo ali. Exatamente. A gente consegue fazer isso. É, exatamente. Isso daí, isso daí é uma fonte de dados riquíssima. É um produto.
02:26
De qualquer tipo de órgão. Entendeu? Então, tipo assim, não vamos falar assim que a gente— isso sim é inovador. Aí o nosso produto. Nós não tá criando uma solução, essa solução. Mas esse produto vem acompanhado do nosso, da nossa expertise.
02:38
Sim, aí o nosso produto— Porque quem que vai tratar esses dados? Você não vai entregar e ele joga e ele trata. Trouxe. Entendeu? É. Tá, então nós tá criando, gente. Nós não vai ter o software lá. A gente, a gente vai ter.
02:49
É nosso. É nosso. Nós tá criando um produto. É nosso. É, e a gente pode entregar. O software pra eles, pra eles visualizarem. Mas por contrato, né, lógico. É, lógico. E aqui tá, meu amigo. Espera, calma.
02:59
É, mas isso aqui é especialista em contrato. Eu falo é porque— Vamos. Então, deixa o copo aqui, meu brother. Tá de indo do ambiente. Tá, tá indo embora. Calma aí. Então vamos lá, ó. A ideia principal é de ontem, até no início agora, era uma e meio que deu uma mudadinha.
03:15
Turvou. A gente vamos— Pivotou. Sim. Vamos focar numa coisa só. Porque eu entendi igual no início ali, não tava entendendo aonde vocês querem chegar com questão de câmera e tal e tal. Agora eu entendi. Que é o quê? A gente pegar o que já existe, sem gastar, sem ter que gastar mais. Tipo, a gente não tem que implementar nossas próprias câmeras, que é um gasto enorme.
03:34
Sim. A gente vai pegar o que já existe. A gente vai— E a gente vai criar um— a gente vai ter um certo tipo de consultoria. Então a gente vai pegar tudo que as câmeras pegam e a gente— é a memória, é o cérebro pra o resto, né, dali pra frente.
03:47
E aí nós vai cobrar pela melhoria que a ideia que a gente vai— Esquece, esquece. Qualquer tipo de cobrança agora, agora. Esquece. Não, eu tô entendendo o eixo do produto. Não, esquece agora. Monetização. Esquece.
03:59
Pensa nas camadas que nós vamos levantar. Sim. Quem que— pô, um trem importante, o cara falou ontem o quê? Se acontece um acidente, que nós sabe o que que— as nossas câmeras vai começar a entender o quê? Cara, aqui é um alto índice de acidente. Beleza, eu tenho um dado. Agora, entender o porquê.
04:19
É outra questão. Aí você percebe que quando alguém parou fora do recute, três metros, cinco metros, que é obrigatório, teve acidente. Não, melhor ainda, reparou que quando é uma caminhonete, donut. Cara.
04:33
Mais a visão. Aí que teve mais acidente. Cara, tem uma câmera que mostra lá, assim, velho. A câmera vai te mostrar que tipo que é o veículo, o tamanho do veículo, entendeu? Tá ali, ó. Então assim. Quem mais mostra isso aí? Você tem que parar.
04:43
A gente entender o porquê. A gente começar a entregar dado de porquê que gera determinado tipo de acidente, ou engarrafamento, ou.
04:51
E aí quanto mais cabeça, melhor. Muito mais porquê a gente tem. Quando todo mundo tiver aqui, ó, sintonizado. Não, entendi. Tipo esse exemplo que eu dei da caminhonete, tipo de dados. Eu não vou conseguir se eu ficar anotando, eu não vou conseguir. Só que aí, hora que junta todo mundo aqui, cada um tem uma realidade. Sim.
05:06
Então as suas informações da praça vão tudo. Você faz da sua vida ali, a hora que junta isso aí, é que tá o negócio, entendeu? É que tá rico. É. Ali, aqui. História no norte. Então assim, vamos supor, trata— vamos começar a fazer uma camada aqui. Vamos pegar a camada dos ônibus mesmo, então.
05:23
Uhum. A gente vê as rotas dos ônibus. Eles, eles— os ônibus têm câmera? Interna, não grava. Externa tem? Externa não. Tem uns que tá lá, umas câmeras nos ônibus. Baratinho. Barato. Mas eu tô falando que essa é a ideia, não.
05:39
É, tem que montar o CCO, né. É, mas vamos, vamos parar. Pegar CCO. Vamos parar pra pensar aqui, ó. O aparato de câmera que já tem na cidade. É uma conversa na sombra. Vamos lá pra dentro? De abraço CCO também na nossa empresa, parceria.
05:54
700 câmeras apagadas. Você Você tem que resolver problema. Bom, não sei. Meu objetivo é resolver o problema, entendeu? Isso aqui é bem teu negócio, você vende. Sim. Como que eu uso? Você fala não, você vai comigo.
06:15
Não, mas não adianta. Isso é problema deles. Pode jogar seu projeto. Então você, você, o mais longe que você conseguir. Né, a hora que o povinho tá se perdendo, mas aí você, você tem que tá preparado. Então a hora que os moços se iluminam, todo mundo tá aí, tá doidinho, infelizmente.
06:37
Nem eu, nem tanto nem consigo cutucar. Já, já, já pegou. Nós já vendemos o nosso produto. Já foi validado, você entende? Nós já— Eu gosto que chega, chega. Nós já teve validação. Agora a gente tem que ser focado na ideia pra gente tá com o mesmo discurso.
06:54
Isso. Nós já nós sentados. E agora nós tem que ter. Eu vou jogar no dashboard e a gente vai. E a gente tem que resumido. Um trecho a gente já explicar tudo. Então o ideal. E pra gente ter menos porquê, nós tem que diminuir.
07:07
Porque os cara chegar e perguntar, ele vai saber falar do mesmo jeito que você. E nós tem que diminuir os porquê. Nós tem que diminuir os porquê. Dar resposta. Acabou os porquê. É, eles não acabaram. Eles existem e a gente vai mostrar eles. A gente tem que mostrar eles.
07:22
A gente tem que mostrar eles. A resposta. E a hora que a gente não chegar, a hora que chegar não tem mais resposta, a gente tem que saber pelo menos indicar aonde tá a resposta. A gente tem que saber indicar. Se você falar não sei, você perdeu.
07:38
Porque a gente fala não, os dados. Não, não sei, não existe.
07:41
Aqui ó, os dados tão com a prefeitura. Nesse momento eu já tô te falando qual que é a resposta. Pra gente não chegar. Os dados tão com a prefeitura. Ou seja, a gente consegue fazer tudo isso aqui, a gente já simulou, já pesquisou, e agora vocês, entendeu? Se vocês entregarem, e se vocês quiserem fazer um piloto, e a gente às vezes a gente consegue até simular sim, a gente sai ali fora, funciona.
08:02
Simula. Dez minutos. E grava e joga ali. Pum. Agora você pensa com todas as horas de 300 câmeras na cidade, que é grave, coloca no nosso mapa e o cachorro amarelo que mora ali, daqui a tanto de cachorro, tem esse aqui, esse aqui, esse aqui, esse aqui, entendeu?
08:26
E aí o cachorro amarelo fez xixi 10 vezes levantando a perna esquerda e duas vezes pela manhã e levanta a perna direita. Porque ele gosta de dormir do lado esquerdo e a perna ficou com isso. Porque ele dormiu duas horas.
08:42
Contar com a onda. Veio pra nós. Ele vai falar assim: “Você não vai pegar uma câmera simples e eu vi lá.”Se eu virar lá pra cá, eu falo assim: “Você não souber que isso aqui é um teclado, mas eu acho que já vai saber, você vai ser o isso aqui, ó.”
09:28
Vocês acabam o café. De lá vem não. Você foi