Reunião de Brainstorming e Planejamento: Mobilidade Urbana em Patos de Minas
Visão Geral
A reunião discutiu amplamente problemas e oportunidades relacionados à mobilidade urbana em Patos de Minas, com foco em transporte público, otimização do trânsito, uso de dados para tomada de decisões e possíveis soluções inovadoras. O grupo debateu tanto desafios atuais quanto possibilidades de melhoria, exemplificando com situações reais do município e analisando propostas já existentes, como terminais integrados, semáforos inteligentes e integração de dados de câmeras.
Palavras-chave: Mobilidade Urbana, Transporte Público, Dados e Tecnologia
Principais Pontos
Desafios do Transporte Público: Transporte público enfrenta problemas de eficiência, conforto e horários incompatíveis com a demanda dos usuários.
Soluções Inovadoras: Propostas incluem priorização em semáforos, escalonamento de horários, uso de dados inteligentes e integração de sistemas.
Uso Estratégico de Dados: Dados coletados por câmeras e sensores podem ser usados para otimizar o trânsito e gerar receita por meio de parcerias.
Desafios Culturais e Financeiros: Investimentos necessários e a cultura do carro próprio são barreiras para a adoção de melhorias no transporte coletivo.
Principais Temas Abordados
1. Eficiência do Transporte Público
Percepção de eficiência: Debateu-se se o transporte público local é realmente eficiente ou apenas atende a um cronograma de parceria, sem priorizar o usuário.
Exemplo: Ônibus enfrentam semáforos e congestionamentos como qualquer carro, não tendo prioridade real.
Conforto e atratividade: Usuários preferem carro próprio devido ao conforto, liberdade e segurança, especialmente em condições adversas (chuva, espera em pontos).
Capacidade e higiene: Questionamento sobre a qualidade dos assentos e a higiene dos ônibus.
Demanda x oferta: Se o transporte público fosse mais eficiente, poderia atrair mais passageiros, aliviando o trânsito.
2. Problemas Operacionais e Impacto nas Empresas
Horários incompatíveis: Empresas perdem funcionários porque os horários dos ônibus não coincidem com os turnos de trabalho.
Exemplo: Funcionários da indústria Gaúcha pediram demissão devido à falta de ônibus no horário de saída.
Ajustes pontuais: Parcerias entre empresas e concessionárias para ajustar horários melhoraram a retenção de funcionários.
Restrições legais: Proibição do uso de vans em bairros limita alternativas de transporte.
3. Propostas e Soluções Inovadoras
Priorização do transporte coletivo: Sugestão de dar prioridade aos ônibus em semáforos, semelhante ao que já ocorre com ambulâncias e veículos de emergência.
Gamificação e incentivo: Estímulo à busca de alternativas criativas, inclusive pensando em como convencer motoristas de carros a migrarem para o transporte coletivo.
Alteração de horários em polos geradores de tráfego: Proposta de escalonar horários de entrada/saída em empresas e escolas para evitar picos de congestionamento.
Exemplo: Mudanças de 15 minutos nos horários da UNIPAM ou Marista poderiam reduzir caos no trânsito.
Monitoramento e dados: Uso de câmeras inteligentes para coletar dados de fluxo, acidentes, e comportamento dos usuários, possibilitando diagnósticos mais precisos e soluções sob medida.
Exemplo: Painéis em pontos estratégicos mostrando em tempo real o fluxo das vias para entregadores e motoristas.
Integração de sistemas: Aproveitar infraestrutura já existente (câmeras, cancelas, sensores) para criar um sistema de mobilidade inteligente e previsível, sem necessidade de grandes investimentos em novos equipamentos.
4. Exemplos de Integração e Modelos de Terminais
Projeto do coronel: Implantação de terminais central e regionais, com linhas alimentadoras dos bairros para os terminais e integração entre eles, semelhante ao modelo de Belo Horizonte.
Benefícios esperados: Redução do tempo de espera (de 15 para 10 minutos), rotatividade mais alta, pagamento único para integração.
Desafios: Necessidade de investimento milionário e mudanças culturais para adoção do novo sistema.
Semáforos inteligentes: Atualmente, apenas 7 dos 72 semáforos da cidade são inteligentes (com sensores/câmeras), mas o objetivo é ampliar o uso para otimizar o fluxo de acordo com a demanda real.
5. Uso e Monetização de Dados
Tratamento de dados existentes: Proposta de utilizar dados já captados por câmeras de segurança e semáforos para diagnósticos de mobilidade e planejamento urbano.
Aplicações práticas: Dados podem ser vendidos para empresas de delivery (como iFood) para otimizar rotas de entregadores, ou para o próprio município melhorar a gestão do trânsito.
Exemplo de aplicação: Desenvolvimento de adesivos (April Tags) para classificar veículos (entregadores, mototáxis, etc.) e aprimorar o monitoramento.
6. Desafios e Limitações
Custo de infraestrutura: Preocupação com o investimento necessário para soluções tecnológicas avançadas.
Cultura do carro próprio: Dificuldade de convencer a população a migrar para o transporte coletivo.
Limitações legais e operacionais: Proibições e concessões impactam a flexibilidade do sistema.
Encaminhamentos e Próximos Passos
Coleta e tratamento de dados: Foco na integração e análise dos dados já disponíveis para subsidiar decisões e propostas.
Pesquisa de soluções existentes: Buscar referências em cidades semelhantes e adaptar boas práticas.
Consultoria e startup: Possibilidade de estruturar uma empresa para ofertar serviços de análise de dados de mobilidade para o poder público e empresas privadas.
Discussão contínua: Manter o brainstorming aberto para novas ideias e ajustes conforme novos dados e experiências forem coletados.
Exemplos e Situações Reais Citadas
Funcionários deixando empregos por falta de ônibus em horários específicos.
Projeto da Gaúcha com a Pássaro Branco para ajustar horários de ônibus.
Modelo de terminais integrados e linhas alimentadoras proposto pelo coronel para Patos de Minas.
Uso de câmeras para monitoramento do trânsito e potencial para integração com sistemas inteligentes.
Possibilidade de uso comercial dos dados para plataformas de delivery.
Resumo Final
A reunião foi marcada por uma análise crítica e multifacetada da mobilidade urbana em Patos de Minas, destacando a importância do uso inteligente de dados, integração de sistemas, inovação em modelos operacionais e a necessidade de considerar aspectos culturais, legais e financeiros para o sucesso de qualquer solução.

Transcription
00:12
A solução ainda está. Travar o nosso cérebro aqui, e partir do lado da ideia deles. Vamos focar primeiro em questões que a gente tem que pesquisar, e depois talvez deixar o mentor colocar as travas que a gente sempre coloca.
00:29
Pesquisa bastante a respeito do quê? Aqui fala no documento que não há. Você mandou? Entendeu? Faz 36 dias, 24% sempre adianta ao invés de atrasa. Isso torna talvez ele eficiente, mas eficiente a olhos de quem? Do cronograma da parceria.
00:54
Entendeu? A gente está falando que ele sai da rodoviária, ou do ponto de ônibus dele para chegar no destino, e gasta um tempo X, Y, Z. Mas ele enfrenta todos os adventos, semáforos, possíveis garrafamentos. Se ele realmente fosse prioritário, ou abrisse realmente com o Enem e falou uma caixinha lá no semáforo, com ônibus, ele poder passar adiante talvez mais rápido. É realmente uma boa parte de Minas?
01:21
Eu vou deixar de sair do meu carro para ir trabalhar, com liberdade de tudo, poder pegar um busão, depois ter que esperar horário, às vezes em ponto na chuva, correndo risco. Então assim, vamos pensar nesse esquema tudo, tá? Todo mundo.
01:36
Justamente, fez uma pegada de surpresa. Volto te falando: o transporte público aqui em Passos, ele realmente é ineficiente, ou ele é eficiente? O número de pessoas que ele transporta por dia, se ele fosse mais eficiente, ele transportaria mais todo mundo, levaria mais transporte público? Os ônibus assentos são bons, são higiênicos?
01:57
Vocês entendem o que eu estou falando? Vocês? A pessoa tem que querer pegar o ônibus. Às vezes, assim, o Enem, pelo trabalhar da casa dele até lá na polícia. Não, Não, nós não vamos entrar. Eu não vou trocar o meu conforto, o meu veículo, por ônibus. Mas outras pessoas que estão deixando de ir de ônibus para ir de carro vão às vezes evitar.
02:17
Juro. Continua porque ele melhorou. Pois é, mas isso aí é um sim que ninguém de nós consegue escolher. Você já deu negativa? Talvez negativa aqui. O meu seria negativo também, até então. A não ser que o nosso passasse na porta da minha casa.
02:30
Mas a gente já deu boa. A gente já circulou o que precisa. A gente tem que começar. Gamificar mais. Então assim, eu quero que vocês pensem. Entendeu? Alternativas, como talvez a sociedade vai pensar nisso. Ah, eu estou no meu carro aqui, porra, vai pensar?
02:53
Vai passar a porra de ônibus primeiro antes do meu carro? Vai ser errado. Mas eu achei excelente a ideia. Por quê? Porque já pega a premissa. Eles ontem que os ônibus eles carregam aglomerados de pessoas, o ponto menos metragem, dentro da cidade.
03:14
Está em top 1 entre as.
03:16
Sim. Então assim, esse atrativo da talvez acesso não vou dizer prioritário, tá? Prioritário realmente a gente colocar a vida primeiro. São as emergências, ambulância, SAMU, enfim. Mas a gente também precisa classificar. Vamos partir dessa ideia de prioridade na cidade urbana sim dos ônibus. Mas vamos tentar de classificação entre as emergências dos ônibus. Emergências ônibus e entregadores eu consigo. A parte entregadores, quando eu falo o quê? Desde o carro. Você pode chegar grande. Por quê?
03:54
Como o Enem disse também, a gente imagina só os entregadores de iFood, marketplace, tendo também talvez conseguindo chegar no local mais rápido também. Um iFood de pagaria, por informação dessa daí não. Entendeu? Ou por um benefício desse daí. Reduzir acidente. Reduzir acidente no mesmo tempo. Entendeu?
04:16
Entendeu? Porque o Zé motoca hoje você está louco. Ele é responsável por tudo. É tudo minimização em algum momento. É. Tudo minimização. Empresa o tempo inteiro. Então tipo assim, ó, a gente vai fazer uma escala.
04:31
Tá? Que realmente a. Ideia base do nosso projeto é aumentar a mobilidade urbana, a ponto que a gente libera as caixas como foi descrito, que são as caixas de trânsito. Você pega elas aqui mesmo, Rafa. Deixa ele aí, sabe de onde? Assim, não. Por quê não? Pega ali as três, três. Vai que não é. Senão por quê não? Senão por quê não? Vai que pega. Só aqui a gente já tem aqui um.
04:59
Bora ver. Bora ver o trabalho? Não. Gente, rapidinho. Só então, o que eu preciso de vocês aqui? Vamos assinar a lista de presença para a gente ficar livre? Assinando na segunda coluna aqui, por favor. Já assinei já.
05:14
Estou com toda a informação. Quando está chovendo, carre Quando está chovendo, carrega mais gente. Quando o sol carrega mais gente. Sim. Outra questão. Está Está perdendo funcionário. Devido a isso, ou seja, o horário que os funcionários saíam não tinha ônibus.
05:31
Então o que acontece? O horário que os funcionários saíam, que acabava de pedir gente, não tinha um ônibus próximo. O horário ali, né? Aí muita gente deixava de ir trabalhar, pedia demissão. O cara lá, o cozinheiro deles, pediu demissão. Por causa disso.
05:44
Por causa de quê? Por causa que o horário que ele saía não tinha horário de ônibus pé. Não tinha que andar. Grandes empresários procuram a parceria para otimizar o horário do ônibus no ponto perto da sua própria empresa.
06:00
Importante isso, na verdade. Está aqui. Então, a Gaúcha teve um, a Gaúcha teve um grande problema por planalto lá, perto do Porto Patrão. A indústria que faz alimento. Estou ligado.
06:15
Ela teve um grande problema. Qual que era a dor dele? A dor dele. Ele não estava conseguindo funcionário que tinha veículo próprio. Então uma faixa etária grande de funcionário deles era de dependente de ônibus. E o horário? E o horário do ônibus não era o horário que o funcionário saía. Aí o funcionário falava assim: “Poxa, eu não vou sair daqui
06:42
eu não quero vale-transporte, eu não quero trabalhar para você mais. Porque para mim não funciona. Porque a Gaúcha fecha 5 e meia. Não, a gente está passando aqui 6 e meia, velho. Quando a FF inicia.
06:54
Aí o dono da Gaúcha vai na pássaro branco, contador, a pássaro branco otimizou o horário de ônibus para passar tanto na hora que a equipe começa e que a equipe finaliza. No horário que fica 5 a 10 minutos esperando. Pronto. Agora ele tem. Já está otimizado.
07:10
Já está otimizado. O que acontece? A gente faz o atendimento do IFM. O IFM vocês sabem o que é. Pertinho lá também. Aí o IFM, o horário do cliente sair é 15:45. Aí o que acontece?
07:24
Aí o IFM, essa turma de 15:45 só tem segunda e sexta. Aí o outro, os outros dias, esse horário de 15:45 dá 7 e o funcionário da Gaúcha. Ou seja, eles foram lá, porque nas férias a gente tira os ônibus que vão para a escola. Ou seja, o IFM, esse de 15:45, não tinha durante as férias. A sala de julgo. Aí o que aconteceu? Os donos foram lá falar: “Ou, tinha um horário tal, tal, tal, assim, aí nessas férias
07:56
áreas que o dono foi lá ou alguém foi lá reclamar? É, essa área dessas empresas longe, igual, sem. A Patense não, porque você sabe por quê? Porque existe um ônibus próprio para eles mesmos. Ah, a pessoa lá que é lá daquele
08:14
seta. Não, da Não, daquele, sabe o rivalcino? Sabe uma casa de idoso que tem lá perto? Eles foram lá. Não pode ter van para onde não? Não, porque igual a empresa, antes, ela tinha micro-ônibus e o ônibus normal. Porém, quando estava muito problema, tipo assim.
08:32
Mas eu falo assim, o setor é outro setor. A prefeitura não pode mostrar van para fazer rotas de ônibus. Você pode ver que aqueles vans amarelos são da prefeitura. Transporte público é da prefeitura. Agora aqui é concessionária, é a sua concessão para Passo Branco. Ou seja, a prefeitura tirou esse abacaxi da cabeça deles, tem que se preocupar com isso.
08:55
Mas olha o que você vê, a última renovação todo mundo aprovou que era proibido ter van. Nos bairros, para dentro dos bairros. Aquela pessoa, exatamente. Você está olhando todo bairro. E o primeiro ponto é 20 minutos de lá. 25 minutos de lá. Solão, chuva, você vai?
09:14
Não vou. Não vai não. Mas olha o que você vê. Hoje é proibido. Então uma das coisas que eu acho que ele deveria colocar é uma mexida de saco. Isso seja cobrado e seja pensado de formas de que essa pessoa não tenha que ir lá no ônibus no primeiro ônibus dela. Porque às vezes ainda tem outro depois. Isso em particular que você vai ter.
09:37
Mas você está pensando em van? Cara, van. Mas você sabe que. Se tem alguém fazendo assim no bairro, que vai. Uma pessoa tem que pagar duas vezes? Cara, paga. Paga. Hoje é proibido. Deixa falar. Mas você sabe, deixa eu falar um negócio aqui, ó. O coronel, ele quer aplicar aqui a sistemática de terminal na cidade. Ele vai fazer. De um jeito ou de outro, ele vai fazer.
10:11
Mas isso não muda o terminal não. Terminais. Eu tenho aqui, eu fiz um projeto para ele, quem fez o projeto foi. Mas não muda para o bairro. Não muda para o cara lá no morador da C, entendeu? Lá naquele bairro mais acelerado.
10:23
É o Jardim Europa. Não muda para o Jardim Europa. Vamos levantar. No final do bairro. Ou no meio do bairro. Aquele que o ônibus vai para alguns lugares, esse nome é uma ferramenta de sistemática. A Valeica.
10:38
A pessoa que mora mais longe. 200 metros. A pessoa na cidade. Às vezes o ônibus corre pela cidade. Para que a pessoa tenha que andar só 200 metros. Quer ver? Ou em média. É no máximo em média. A professora da aula lá da ilha.
10:57
E aí o cara. O mapa, você pode tirar o mapa, ele é bem tranquilo. Você pode ver, eu vou te mostrar. Não tem transporte público para lá. E tem de Uber e tem de carro próprio. Não tem conduta. Precisar assim, a gente vai eliminando os negócios.
11:09
Então pode ver que existe poucas. Poucas áreas que estão descobertas. Sim. Você consegue entender? Existe poucas áreas que estão descobertas. Principalmente que. Talvez exista uma área ou outra, lógico, né? Mas você pode ver que o mapa de calor, se você pegar, ele é bem distribuído. A cidade toda. Te dou
11:29
Te dou um exemplo. Não existe dentro da área da rua é um aplicativo existente de carro ou não? Para mim, para a pessoa. Sim. Entendeu? Gente, eu dou um exemplo. Olha aqui, ó. Legal? Onde que é a primeira linha aqui?
11:43
Aqui, ó. Para quem está aqui, ó. Aqui é o laranjinha ou o cinza? Laranja e cinza. Beleza. Você está. Você mora de a pé. Pagar o Uber faz. Sei lá. Sei lá. Aqui e o que aqui serve é essa. Ou aqui e aqui serve é essa. Ou elas vão e vêm.
12:00
Vai e vão. É, está vendo? Ambas são assim, assim. Então beleza. Está indo bem. Tem duas linhas? Então realmente, é aqui, ó. Aí já tem a vida e a rota. Aí aqui, ó. Você mora aqui, ó. E todo dia você precisa pegar essa linha aqui. Ou essa linha aqui. Você escolhe. E aí você tem o Solão do meio-dia, você tem a chuvinha, aquele sereninho.
12:20
Um exemplo. Eu. Um tempo de dormir para você ter transporte público. Isso não dá para você ter que pegar o outro depois. Paraíba e pega o outro. Sim. E aí dependendo. Lá no aplicativo sinalizado. Depois às vezes chega num lugar e faz um. Mas todo
12:39
Mas todo barrinha ficou fininho. Não, eu entendo. Eu vou negociar. Para ela não ir para lá. Entendeu? As pessoas que moram de frente. Mas é uma ideia bacana. O problema da residência. Isso. Aí o que acontece?
12:58
Não vai tirar o senhor. Para convencer. Porque ele é bem barato. O cara vai gastar 30 reais de ônibus e não de carro. Eu sozinho vou gastar no meu carro. Para chegar no Ipanema todo dia. Dependendo do salário que eu ganho, vai apertar.
13:12
Mas eu posso pegar. A 5 reais cada um e um pouco mais caro do que o transporte público, porque vai ser mais confortável. Um pouco mais barato e vou marcar com ele um compromisso. Ô, brother, essa semana, de segunda a sexta.
13:33
Daí o cara é para economizar, vamos lá na cidade. Porque tem muitos carros andando. Nós só vai criar um problema. Você pode combinar com o nosso sistema. Não recebe. A gente está garantindo 3 bikes, 5 carros.
13:57
Tem 1 banco. A Valeica bate muito no ponto de questão de gasto. Você pode ver que ela falou 32 milhões. Como vai ser só. 17 mil. 17 milhões. Funciona de jeito aqui, ó. Ele andando de mão da vida toda, não paga.
14:16
De viagem? Não, de desconto. A pessoa passou o ônibus. Depende do pico, né? Depende ali da faixa de horário. Entre pico, por exemplo. Mas é 20, no máximo. Máximo 20. É, não é pouco não. Você pode ver que o sistema.
14:37
Comparado com outras cidades, aqui é perfeito. A gente percebe isso muito bom. Só que o que acontece? A Valeica bate muito no ponto nessa questão de tudo. Eu acho que isso é o principal. Eu posso vencer essa pessoa que está no carro com um selão que o ônibus não tem.
15:03
Não, isso é impossível. Tem um dado aqui que é muito importante. Eu tive lá no passado. Funciona. Não, é igual você fala, funciona. Eu gostei de metrô no São Paulo. Funcionar mesmo, funcionar. Então o povo é meio que assim, ó.
15:35
Lá é diferente, porque é muita bairro, A bike é. A operação é. De 30 minutos. Fala mais alto que o povo aqui. A operação. A operação de horários fixos.
16:13
Ou de entrada e saída de empresas. Que é o quê? É o clássico, galera. Ou 7 ou 7 e meia da manhã, 11 horas horário de ônibus, meio dia retorna essa porra de propriedade aqui também trava pra caralho. Entendeu? Então assim, vários pontos. Marista trava pra caralho. Entendeu? Esses órgãos de grande porte, macroporte, a gente também colocar influência deles no fluxo pesado das caixas de parto de Minas. Beleza? Beleza? Como assim fluxo pesado da caixa?
16:50
Valoriza o centro da cidade. O centro da cidade com os robóticos, os artesanatos. Você tem ali várias lojas com dezenas de pessoas, centenas de pessoas que trabalham lá.
16:59
Você passa por uma cadernetinha, um tablet, vai anotando. Você mora onde? Você vem de carro? Você vem de quê? Ou você mora onde? Você vem de quê? E o horário que você chega. Ou você mora onde? Você vem de quê? E o horário que você chega. E aí você vai fazer isso, plotar um mapa de calor e propor uma distribuição de chegada de horário. Vai intervalando de 5 em 5 minutos. Você conhece a partir de amanhã você chega 7 e 5 em vez de 7.
17:23
Porque você vem do mesmo bairro que o fulano de tal, e ele vai chegar 7 e 15, 7 e 30 no máximo. Porque você vai fazendo isso aí, entendeu? Primeiramente nos locais de grande fluxo.
17:37
É isso. Um exemplo. Um exemplo são o MIPAN. Olha o texto comigo. Imagina se o MIPAN altera em 15 minutos, 20 minutos o horário de chegada das 7 horas da noite. É um caos, velho. Você vem lá do Moisés para você atravessar para lá. Aqui ó. Você não anda no centro. Aqui ó.
17:55
Nós está falando. Aí o povo sai do trampo. Nós está falando. Aqui começa 7. Aqui ó. Nós está falando. Os ônibus que vêm da cidade de volta. De fora assim ó. Aqui ó. Mano, nós está falando. Semáforo inteligente já tem. Nós está falando da câmera de otimização do semáforo para o serviço de emergência e transporte público.
18:19
As câmeras de adaptação. Isso. Vai escutando. Nós está falando de coletar dados nas câmeras. Beleza? Um dado importante que eu gostaria que as ruas fossem inteligentes. Pelo seguinte. Meu sonho.
18:37
Meu sonho. Ter um olho no bairro, na esquina da frente que está acontecendo, mano. O que acontece para os entregadores? Se a câmera é inteligente, e ela pode coletar dados, existe o termostato dentro do mapa onde ele fica a área de fluxo. Vermelha, laranja, amarelo ou verde, certo? Nós podia além dessa câmera inteligente ligar com o mapa mais não precisar do usuário saber o que está acontecendo na frente, abrir o mapa no celular.
19:12
A gente podia pegar lugares ociosos que o trânsito é mais lento e parado e fazer um entretenimento naquele lugar. O que poderia fazer? Eu se eu fosse o entregador do iFood, eu adoraria parar naquele inferno daquele balão da Volks que eu fico esperando 10 minutos ali de frente do seu Zé para me poder atravessar. Ter um telão para me saber se se eu virar para a esquerda está vermelho, se eu virar para a direita está alaranjado, se eu for reto está verde.
19:43
Então a câmera pode adiantar, a câmera que está lá na frente montando dados para cá, nós precisamos das câmeras captando dados de como que está o fluxo da rua, e aí eu vou estar ali no lugar ocioso e eu já sei o que eu vou virar. E isso aí vai dar um, vai ter uma visão.
20:07
A pessoa vai andar com uma visão na frente, mano. A gente adivinha só na hora. A gente adivinha só na hora, mano. A gente adivinha só na hora. Nós adivinha só na hora. Então a plaquinha, uma esquina antes. Aí tipo assim.
20:22
Aqui ó. Tem acidente aqui. Isso. É, tem um carro parado. Porque a câmera lá na frente. A câmera lá na frente já adiantou o problema, o telão que está dois bares, e aí nós usamos a câmera inteligente para isso aqui tudo, mano. É.
20:43
Não, só que muito, mano. É só em lugares ociosos. Você pega ali José de Santana, você pega ali ó, você pega ali onde? Na José de Santana que a doutora Marcolino, você pega ali no Imaculada, você pega ali no Sideral,
21:08
é o seguinte. Deixa ele falar um negócio daqui sabe adiante. Estamos num campo onde. Falei sobre as caixas, né? Número de pessoas na via, um ônibus consegue economizar espaço disso, então a nossa ideia é que a gente pesquisar sobre.
21:43
Possibilidades da gente agregar também talvez a um semáforo uma luz diferente. A ponto que o transporte público que leve mais pessoas ele consiga ser prioritário se tem um ônibus vindo às vezes na via ele consiga passar antes talvez dos outros carros que ele leva mais pessoas ao voltar antes.
22:07
Está bem interessante. No entanto a gente não vai ficar só nessa. Nós estamos pesquisando também possibilidades de entender melhor como que as vias funcionam. Como que a. Quando o pessoal entende as coisas.
22:21
Como que é o. Olha só para você ver. Uma proposta de desenho que a gente vai colocar é alteração de pequenos horários em grandes polos movimentativos. A UNIPA é um deles. Legal. Assim, a UNIPA é um deles, o Marista é outro, enfim, locais que têm grande relação de carros. Então eles precisam entrar, precisam sair, entendeu? Imagina, todo mundo chega às 7 no trampo ou 7 e meia, sai às 11.
22:50
7 às 30 fecha. Volta meio-dia ou meio-dia e meia, sai 5 ou 6 da tarde. Então esses horários que são os de pico, eles já são de pico normalmente. Então se empresas que entregam muitas pessoas, que têm grandes estacionamentos, ou instituições em si, tiverem pequenas operações, talvez a gente consiga uma mobilidade melhor, agregado também ao transporte público em tese ser importado.
23:18
Pesquisar aí eu falei, tem que entender como funciona o trânsito, todas essas questões. Mas são caminhos, caminhos interessantes para conversar.
23:28
Eu acho que patos, precisa de um olho adiante. Você está na esquina, você está sabendo o que está acontecendo na esquina de frente. Então tem câmera na cidade inteira. Essa câmera consegue mandar um parâmetro, sabe? A quantidade de fluxo, como se fosse um termostato de cor. E daí se eu sou o entregador de pizza, e aí eu estou numa área ociosa que o trânsito é mais lento, ele está com um painel que as câmeras lá da frente estão registrando em cores o que pode estar acontecendo.
24:02
Aí eu vou ter três caminhos, eu vou escolher o mais leve. Mas aí já é uma solução, né? É, isso aí só está começando. Não, mas é legal. É isso mesmo. A gente tentar achar material para embasar e ter um ensaio.
24:21
Nós estamos aqui com todas as os tempos e prazos da pasta do branco, ele trabalha, a gente tem alguns privilegiados a respeito disso. Hoje a gente vai começar a entender os outros fluxos. Dessa região a gente pode macro transporte, entendeu?
24:36
Assim mais ou menos isso. Será que essa ideia não é cara? Hã? Essa ideia não é cara? Quem envolve a questão da infraestrutura, né? Qual a infraestrutura? É igual essa aí que ele falou. Não, painéis esquece.
24:55
Qual que é a ideia principal de fazer? É o seguinte, se.
25:00
Seguindo as premissas da apresentação, hoje o transporte individual, o carro pequeno, ele transporta às vezes uma ou duas pessoas, ele ocupa uma porcentagem muito grande da caixa de transporte, das vias. O transporte público, os ônibus, os transportam mais pessoas, 50, 60 pessoas, eles economizam muito espaço da via. Então hoje existe um transporte prioritário que são SAMUs, ambulâncias, que passam às vezes no semáforo e chegam em determinado local e precisam chegar lá mais rápido.
25:34
Quem sabe uma pequena mudança talvez, legislativa ali, que o ônibus consiga passar um pouco mais rápido também. Liberar a via mais rápido para mais pessoas. Isso é um ponto. O segundo ponto é um estudo aonde. Locais de grande concentração de públicos, no caso, UNIPAM, Marista, escolas em geral, empresas com número grande.
26:01
Expressivo de funcionários, que também causam certos grandes engarrafamentos no trânsito. Por quê? Chegam no mesmo horário, para trabalhar, 6 e meia, 7, 7 e meia, saem para almoçar, 11, 11 e meia, meio-dia, chegam do almoço, vão para casa à tarde, então imagine só se às vezes a UNIPAM, que vem ônibus de fora, trava aqui, chegando pela todos os locais aqui de fora, preó, Lagoa Formosa, um monte de local, vem tudo chegando aqui 7 horas. E coincide com o pessoal saindo do trampo 6 horas, 6 e meia.
26:36
Imagina se a gente conseguisse alterar um pequeno horário talvez das empresas para chegar um pouco mais cedo ou mais tarde, alguma coisa desse tipo, em locais que têm grandes entradas e saídas de veículos. Mais ou menos essa premissa aí.
26:56
A gente divide em três horários de cinco ônibus. Esse ônibus não pode passar nessa via aqui, tem que passar por tal lugar, tal local, entendeu? A gente tem que pensar seria qual? Alterar rotas? Não, a gente não pensa dessa forma não, está tudo pesquisando ainda.
27:16
Mas é mais ou menos nessa linha. Tirar a movimentação de determinados horários. Porque tirar os veículos vai ser difícil, deve estar a cultura, as pessoas vão pegar mais ônibus coletivos. Mas talvez pequenas alterações a gente consiga.
27:38
Segura aí. Deixa aí. Talvez. O que vocês sugerem, podem sugerir, não precisa ser nada inovador. Pode ser algo que já existe em algum lugar do mundo. Cidades próximas de portos parecidos, compactos, o que o pessoal já fez dentro dessa problemática?
28:08
Mais alguém já estudou alguma coisa que a gente pode aplicar? Já tem muita coisa validada. A gente trouxe muitas coisas que já estão validadas, mas não tem prática. Mas pode sair novidade, né? O iPhone veio do iPod.
28:25
Entendeu? Pega a ideia de alguém que já tem melhor ela,. Então vamos ver o seguinte, vai. Conversa. Moral da história: a ideia está muito aberta, está. Muito aberta. Então vamos lá, vamos lá. A questão de focar em tirar o número de carro pequeno da rua, será que os feeds de papai que os moleques cruzam do Marista permitiriam o ônibus trazer essa modalidade de gente para cá?
29:03
Vai sair frete para lá todo mês. Para onde? Para o Marista. Quantos alunos? Qual a porcentagem de aluno que vocês pegam? Tem um pessoal de escola pública que vai, tem muita pessoa. Qual a porcentagem de aluno de escola pública que é pasta do branco que pega hoje?
29:17
A gente está abrangendo aqui o crescimento exponencial da pasta do branco. Dados aqui, IA da pasta do branco. Mas e a lei do cinco, velho? Nós estamos só ganhando dinheiro com os caras aí. Pode estragar tudo.
29:40
Toda semana tem frete para lá. A gente faz com a mil reais para eles. Esse sítio aqui. Responde uma pergunta. Responde uma pergunta. Qual a porcentagem de macrocirculação que vocês atendem? Escolas, empresas de grande porte, como as grandes escolas?
30:01
Locais de grande porte. 30% do. Vamos pegar aqui, pega daqui e vai até do outro lado. Pega as escolas do docê. Por que os pais levam, sei lá, os moleques buscam na escola? Se tivesse um transporte da porta para casa, ou ali perto de um ponto, se for com uma velocidade de ônibus, e deixasse, sei lá, perto para poder voltar para casa, pensa nisso. Porque velho, você está louco.
30:27
Segurança? Marista aqui é um caos, velho. Marista aqui é um caos. Ali, por exemplo, a câmera tem esses indicadores aí. Aí é que está, é uma startup. Em tese. Em tese é startup. A gente está oferecendo aqui, primeiro, a gente vai pegar, a gente vai oferecer consultoria, consultoria, tratamento de dados, metodologia própria, startup de software, startup de hardware, tudo junto.
30:58
Você entendeu? Outra visão é a que está oferecendo consultoria. Ah, mas startup de inovação de consultoria? Que exige enfim. Não sei, estou dando ideia. Porque o que visualizou a primeira vez? Você vai comprar pelo quê? Agora como monetizar? A gente juntou o que tem aqui e vai comprar o quê? A solução.
31:23
Não pensa na solução. Não, mas o que acontece? A gente vai estar dando os meios para. Você Você não me respondeu a pergunta. Até agora. O que é? 30%. 30%? 30? Desse todo aqui, você carrega 30%. Beleza.
31:41
Todo mundo é travado de grande empresa, gente. Menos mais. Nós temos as informações e fez material onde pesquisou os horários de quantos carros passam aqui nessa rotatória, determinada hora da manhã. Quantos ônibus? Quantos caminhões que tem lá na BR que vocês transportam?
32:03
Quantos que é de dentro da cidade? Então aqui, transporte de entrega de empresa grande aqui dentro da cidade. Ele trabalha na Ambev, na logística. Esse tem 28 caminhões. 15 roda dentro da cidade. Como que vocês separam as rotas?
32:23
O bairro. Tipo, o caminhão X vai para o norte, e aí que horário que ele sai? Sai 7 horas da manhã. E que horário que o caminhão retorna? Então aqui, na Ambev, na Ambev sai 27 caminhões, na Ambev sai 27 caminhões, 7 horas da manhã, e na Ambev retorna 27 caminhões, 5 horas da tarde.
32:51
Então tem que arracar todas em 26 aqui. Mas não tem forma de. Não Não tem não? O nome aqui é uma identidade. Mas sabia que abrange muito? Eu não sei o que é, onde você quer chegar com as questões dos caminhões, mas sabia que foge da.
33:08
É o nosso eixo. Eu acho que a gente tem que focar em quê? Eu acho que a câmera tinha que ser inteligente.
33:16
Captar dados. É os dados que vão nos reeducar. É os dados que vão saber o que nós precisamos. Sem dados, nós não sabemos fazer nada. Você quer trocar de carro? Você ganha um valor X. Como que você vai saber quando vai trocar de carro? Você precisa de dados. Você precisa de contar quanto você recebe, quanto você paga. Mas ela não está guardando dados aonde? De quê? Para quem? Usar como?
33:40
Eu acho que nós estamos dando essa empresa que pega os dados que já existem e trabalha neles. A gente tem que consultar esses dados, porque a gente consegue fazer com esses dados. Arrumou aquela rua lá, quantas vezes? Resolveu o quê? Deixou de passar quantos carros? Agora passa quantos carros? Quantos que ainda detalha?
33:59
Câmera é 90 graus. Vai precisar de contar o que acontece. Nós pesquisou. Desde 2024, foram quase 80 milhões dessa empresa vocês.
34:23
Jogaram. Ela faz infraestrutura, o rádio, o firmware, o software, manutenção, o carro tem caminhões, ela tem fábrica própria, uma empresa grande, se não me falha a memória, são 32 semáforos que ela já controla, o que eu não observei para vocês é o que realmente eles extraem desses dados, mas já tem uma conjuntura de rota, mobilidade inteligente. Já tem uma conjuntura que eles analisam,
34:54
Já tem uma conjuntura que eles analisam, entendeu? Mas câmera, câmera é igual a gente sabe, ela tem. Potencial para carro. Pode ser junto com a segurança pública. E todas poderiam ser inteligentes, é isso que não está sendo aproveitado.
35:16
O que a gente deve ter de integração? Isso pode? Cara, vamos pesquisar. Mobilidade inteligente e previsível. Vamos mobilidade inteligente. Não, nós não. Eles. Mas aí onde a gente entra como empresa? Como ferramenta.
35:38
Mobilidade inteligente. Vamos fazer essa entrega dos dados e eu te entrego isso. Não sei. Mas as câmeras dão acerto, sabe essas câmeras de início e fim? Não. As câmeras dão acerto? Os caras fazem. Você sabia disso?
35:55
Não. Veio a Ford um pouco da frente. Mas os caras fazem o quê com os dados? Literalmente só de segurança. Só de segurança. Está lá, as imagens estão lá. E está lá de um jeito assim? Está lá. Está lá. É isso.
36:11
Se eu virar presidente do sindicato hoje, se eu brincar com o Márcio, você me ouve? Deixa eu te colocar um. O que as posso trazer de dados? Não só segurança? A gente vai ter, a gente vai trabalhar. Como assim?
36:33
Não sei. Onde é que está? Geralmente não são. Olho vivo. Olho vivo aqui de fato são uns 30 dias. Não é muito. Mas é intervalo, interessa. Você vai pegar isso aí, você sai, depois vai ficar travado. Mas beleza.
36:52
O conceito do nosso ideal é turvar tudo com a integralização e tratamento de dados? A gente esqueceria completamente mobilidade porque até então o tratamento de dados ele tem que levantar alguma coisa para ter uma tomada de decisão.
37:09
Beleza? Os nossos dados vão realmente levantar decisões para quê? Para quem? É para dar mobilidade, é para a gente cumprir previsibilidade, probabilidade. E se você pegar e tratar isso daí também? Vamos estruturar o quê?
37:28
Nós temos aqui o. Rotas, mas enquanto a empresa eu resumi aí no WhatsApp. Três linhas. Não é uma coisa que talvez a gente investir tanto em transporte talvez. Mas a prefeitura se importa muito e o sistema de rastreamento, a prefeitura tem acesso. Então essa parte de privação já possessão, é uma concessão.
37:56
Então a empresa está servida à prefeitura. Então qualquer coisa que precisar, eles estão lá, justamente. E o transporte por. Hoje, é eficiente? Sim. É eficiente? Sim. Só que o gasto igual ela falou, no ano precisa de 32 milhões e a prefeitura passa 17, ou seja, passa ali da
38:26
valência e o coronel diz que é? O coronel quer transformar a cidade, ele quer trocar todas as ruas, quer fazer binário, uma vai e outra volta. Aí a gente já viajou, vamos falar por agora, aí já são muitos anos. Buscar, obra, investimento, milhões e milhões e milhões.
38:44
Mas essa parte é a mais básica, acredita? Trocar o sentido da rua é o mais básico que ele quer fazer. Ele está fazendo já. Você viu lá ele falando, vai trocar isso aqui, ele colocou as ruas lá que ele quer.
38:56
Aí o que ele quer? Ele quer pegar o ponto central, refazer ele todo. É o mercado? Não, ali antes. Está bom, o ponto central ali, a antiga rodoviária? Ele quer cortar ele todo, talhar, sabe aquele estacionamento 45 graus que tem lá atrás? Ele quer tirar aquilo ali, todas as linhas sem exceção de nenhuma, quer passar lá, porque ali vai ser o terminal central.
39:20
O que vai ter o ganho? O que vai ter o ganho? Aí acontece. Aqui não passa condições, vai ser o terminal norte. Lá na igreja do capuchim vai ser o terminal oeste. Lá na igreja de São Batista vai ser o leste. Lá no Bahama vai ser o sul.
39:34
Aí ele quer ligar, quer fazer igual lá no horizonte, eu acho. Colocar as linhas alimentadoras dos bairros nos terminais. Entre os terminais tem um ônibus só, ou seja, a pessoa paga uma vez, vai ter ônibus de 10 em 10 minutos do bairro para o terminal, e o terminal para os outros terminais de 10 em 10 minutos.
39:54
Então iria diminuir de 15 para 10. Isso. Teria ali a rotatividade alta. De 15 para 20. A sua ideia envolve construção? Porque o que eu quero fazer? Não, essa é a ideia do coronel. Essa é a ideia do coronel.
40:12
Beleza. Você sabe o que é as integração? Você sabe? Aqui a gente tem que. Você sabe o que é integração de ônibus? É bancada. Precisa olhar assim, não vou fazer. É isso. Eu tenho um projeto de terminais aqui.
40:31
O que eu tenho? O que eles já têm, você sabe o que tem? Agora que a gente consegue pegar esse dado seu aqui e falar neles, fazer esse quesito. O quê? Esse quesito aqui não é o quê? Mostrar, por exemplo.
40:47
O que é o que entra na porta aí? Esses investidos. Eu posso complementar? Isso aqui é o coronel. Fazer e ele vai fazer isso aqui. Sendo hoje ou não, ele vai fazer isso aqui. Está vendo aqui? Essas linhas que têm cores, elas são pontes alimentadoras, são linhas alimentadoras. Ou seja, sai do bairro e vai para o terminal.
41:17
Vocês fracos, querem integração de ônibus? Não dá para ver. Os azuis são entre terminais, está vendo esses pontinhos azuis? São os terminais. Igual eu falei para vocês. Ponto central, todas as linhas vão passar aqui.
41:43
Todas. O que ele quer fazer? Ele quer fazer a colmeia. E ele vai fazer isso aqui. É isso que eu quero que vocês entendam. Como ele está determinado a fazer isso aqui e a valência também, e essa é a melhor gestão que já teve dessa parte de trânsito.
41:59
São quantos milhões? Isso, é milhões. Pois é. Isso aqui ele vai fazer. O que diz aqui para o que a gente está desenvolvendo aqui? O que você quer mostrar? Ele acredita muito nessa parte de semáforo inteligente.
42:15
Ele diz que dá. Então o que ele deu de exemplo lá? A rua está deserta, não tem ninguém passando, e o semáforo está fechado para o cara. Essa é a galinha de ração dele, que é o quê? Não tem uma alma viva nessa rua aqui. E tem um zilhão de carro aqui, e mesmo assim o semáforo está fechado para quem? Para onde tem carro.
42:35
Por causa do temporizador. E ele quer o quê? Colocar. A gente tem 72 semáforos hoje na cidade. Sete só? Sete só. Então a gente está em que ponto? De quê? Só temporização? Se aqui inteligente, sete só. Porque se você pegar uma jogote, passa de sete.
42:55
Inteligente é porque tem câmera. Não, inteligente é que tem o sensor de quê? Tem a câmera e tem o sensor. Porque ele deu o exemplo lá da parada 4. Se aqui tem zero carros e aqui tem, o semáforo aqui está fechado?
43:06
Esse sensor é de quê? Ele tem um sensor e abre para onde tem carro. Mas esse sensor é que jeito? É no chão, igual radar. No chão? Igual radar e tem a câmera. Você pode ver? Mas só precisa da câmera. Você pode ver que a parte.
43:24
Troca o sentido de tudo. Para mim. Não tem a foto que ele tira lá da avenida para cá. Tem lá o poste lá. De repente, quando você fala. Uma criatura inteligente, para mim pode ser classificada de 0 a 20.
43:45
Isso. Está uma câmera inteligente. O que elas resgatam de dados? O que a análise que ela faz de dados? É só para liberar sinal? Sim ou não? É só isso? No momento, sim. Por que sim? É um infinidade de. Mas isso é o que ele já está fazendo. Ele está querendo de câmera.
44:12
Isso. Aqui. Isso aqui é o que ele faz? Isso é a qualidade aqui. Está vendo? Esses postes aqui. Vocês são. Aí o que ele faz é justamente isso já. Vira aí, vai. Aí vocês querem colocar o radar na câmera do presidente?
44:38
Coloca na. Vira para cá. Você quer para ver quanto cara está na rua? Está vendo vocês. Pois é, já está me filmando lá. Isso com a qualidade da câmera de webcam. Se a gente pegar as 300 câmeras. E aí entra na. Por que essa porcent
44:55
Por que essa porcentagem? Resumo. O O trecho do nosso projeto. Agora entra no WhatsApp que eu acabei de mandar. Se atende o que eu falei, o que vocês falaram, o que ele falou. Nada juntar. Dados. Guardar dados. Esses dados vão servir para melhorias.
45:31
São fontes. Aqui. As câmeras não têm toda a verdade. Uma pessoa tem. Não veio. Não, aqui. Engloba você e tudo. Ruas com memória, mobilidade com previsibilidade. E é o ideal. Valeu tudo. Ao mesmo tempo.
46:07
Entrega para ela. Entrega para ela. Foco de ataque. É o seguinte. Hoje, o próprio coronel disse que a valência disse que as dores trabalham duramente todos os dias para poder melhorar a questão de trânsito. E agora foi implementação de tecnologia.
46:39
Todas as câmeras que os semáforos têm fazem menos apenas 7. São inteligentes. Inteligência a que ponto? O que elas extraem desses dados? É só poder deixar um carro passar ou não, porque a via está cheia ou não, é só isso que esse sistema pode entregar.
46:55
Quantas câmeras realmente têm impacto de linhas?
46:59
Que podem ser utilizadas com esse sistema? Sem necessariamente ser por um semáforo ou não. As câmeras do cinto de metal, as cancelas que implantou, as da polícia, a gente pode chegar a um ponto que a gente trata essa informação e entregar um diagnóstico, talvez melhor, de quão caótico realmente é o trânsito para as linhas, que hoje ninguém sabe. Às vezes dados só superficiais.
47:24
Porque realmente pouco é monitorado. Então, a nossa ideia é parte de câmeras, só que integralizadas. Porque hoje não necessariamente você precisa ter uma câmera própria para isso. A gente consegue integralizar um sistema que a partir das imagens trata isso em camadas.
47:50
As que já existem. As que já existem. As que já existem. Não precisa de comprar nada. Inclusive essas da câmera. Usa o que já existe para poder tratar os dados. Nós oferecemos a solução para pegar esses dados.
48:04
Tratar isso. Copiar e colocar. Foi um cachorro. Foi um cachorro. Foi uma atravessar fora da faixa. Um acidente foi isso aqui. Quem realmente está duro para poder melhorar a mobilidade. Cara, tem um gargalho aqui e outro ali. Que são invisíveis hoje, porque não tem monitoramento. Só tem travamento na cidade, mais nada.
48:28
A solução hoje vem através. Não tem solução ainda. Não é a nossa. A solução que a prefeitura arruma hoje é através de dados de acidente. Boletim de ocorrência. Boletim de ocorrência. Morreu dois aqui. Por que ele morreu?
48:44
Agora. E aí arrumou o balão. Parou de morrer. Agora está passando antes de arrumar o balão. Morreu dois, mas passava um milhão de veículos aqui. Agora arrumou o balão. Não morre ninguém mais, mas ninguém passou mais.
49:00
Agora esse comércio sofreu por isso. Agora a câmera inteligente além dela mostrar o porquê, colocar ajudar a implementar a solução, ela vai viabilizar essa solução por boa ou não. Ela vai te dar uma solução.
49:17
Para a gente replicar essa solução. Em outro local. Então assim, um exemplo. Você quer comprar uma casa de praia. O que você precisa fazer? Você precisa ter dados. Qual o valor da casa de praia? Qual o valor que você ganha? Quanto tempo você compra? Se vale a pena para você. Então qualquer decisão que nós vamos tomar na vida, nós precisamos de dados.
49:36
Ele vai começar a faculdade hoje. Quanto tempo ele vai começar? Quanto tempo ele vai terminar? Quanto vai ter de retorno? Ele precisa de dados. Quando a gente arruma a solução, se a gente não tem dados, nunca. Dados de boca, dados de lote, dados de acidente.
49:51
A IA está aí para isso. Resumindo. Resumindo. Resumindo. Nós vamos usar. Com inteligência. Digamos que um servidor consegue captar o visual que nós já temos hoje implantado em Paço de Minas e a gente consegue tratar isso e entregar um diagnóstico para quem realmente resolve.
50:16
Criar uma tecnologia de compilação e de tratamento de dados. Nós precisamos de um cérebro. Câmeras que já existem na cidade. Disponibilizar isso para a prefeitura. Ou para quem resolve o problema. Tratar. Ruas ali.
50:33
Tem câmera? Não tem lá? Está monitorando alguma coisa? Aqui. Eu quero abrir. Tem dois comerciantes. O dono da padaria e o dono do barzinho. Beleza. A padaria vai funcionar em qual via? Onde o pedestre passa mais vezes.
50:51
E o barzinho vai funcionar onde? Onde o pedestre passa mais vezes. Voltando. Aí o comerciante compra o reverso, o cara não vai atravessar, para ir lá comprar. O cara fale. A câmera tem dados. Vamos tirar a nossa loja sobre o barzinho, se é da padaria, se tem que calar. Vai duplicar, duplicar.
51:17
Para a gente ajudar o sistema. Então vamos ver se aquela pessoa aquele. Objeto. E a qualidade da câmera, obviamente, se melhorar.
51:38
Imagine só se a gente conseguir desenvolver um pequeno adesivo, um April Tag, a gente classificar todos os veículos que mobilizam dentro de Paço de Minas. Quantos realmente estão entregando? Shopee, Mercado Livre, quantos estão ali nos mototáxis, quantos estão ali trabalhando independente, entendeu? As câmeras. Devido aos entregadores.
52:01
Moto agora vai bicicleta leve. Da Santa Casa lá, quantas mil. Carros da urgência lá são relativos ao acidente de trânsito e um percentual de moto é assim, eu não sei se certo ou não, mas é assim. É o maior por isso.
52:24
Então já é um pouco. E aqui? Aqui.
52:27
Esses dados são tão importantes e tão valiosos porque aqui, hoje, suponhando que eu sou proprietário de um aplicativo de carro ou de um iFood, o iFood é vinculado na API, ele vai pagar para ter nossos dados, vai comprar nossos dados. Para o iFood criar uma melhor rota, o entregador dele, porque a nossa câmera captou que no quarteirão da frente está ocioso, está cheio. Então o iFood vai ter uma memória, um cérebro que vai desviar o entregador pela rua de baixo.
53:01
Então a câmera adiantou o nosso problema. Para resolver essa determinado lugar, ocioso, eu fui para a frente, fiz amostragem, contei para as pessoas, instantâneo. Mas tem um subsídio. Quanto mais