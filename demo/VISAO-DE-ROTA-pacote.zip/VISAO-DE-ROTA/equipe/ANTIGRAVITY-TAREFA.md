# Tarefa para o agente do Antigravity — Visão de Rota (hackathon, Patos de Minas)

> Abra esta pasta no Antigravity e peça ao agente: **"leia ANTIGRAVITY-TAREFA.md e execute a tarefa 1"**.
> Escrito pelo arquiteto (Claude Code, sessão de 19/09 14h35). O painel e a pesquisa estão nesta mesma pasta.

## Contexto em 6 linhas
Time **Visão de Rota**, hackathon de mobilidade em Patos de Minas (MG), entrega domingo 20/09 16h, banca 17h.
Proposta: **ler as câmeras que a cidade já tem** (240 em 140 pontos) para contar trânsito — sem rosto, sem placa —
e medir o **antes e depois** de cada mudança na via. O diretor de mobilidade disse ao time (áudio transcrito em
`gravacao/txt/`) que um centro de controle completo custaria da ordem de R$ 320 mil/mês e 40 semáforos
inteligentes R$ 6 milhões, e que hoje **1%** dos semáforos fala com uma central. Nosso argumento: começar por
uma mesa, lendo o que já existe. Painel de demonstração: `gestor.html` (abra no navegador).

## Regras que valem aqui (não negociáveis)
- Todo número tem origem declarada. Três etiquetas: **MEDIDO** (dado real), **SIMULAÇÃO** (cálculo nosso sobre
  dado real), **DADO SINTÉTICO** (inventado para a demonstração). Nunca misture.
- Nada de rosto, placa, nome de pessoa, nome de empresa privada, valor em R$ de cliente, "100%", "único",
  "garantido".
- Dado do transporte coletivo (relatório da operadora) **não sai desta máquina** e não entra em peça pública.
- Não publique nada. Não faça commit sem o Enio pedir.

## Tarefa 1 (prioridade) — Simulação de rua com ferramenta aberta
Monte, com **SUMO** (Eclipse, código aberto) + mapa do OpenStreetMap do centro de Patos de Minas, uma prova de
conceito que mostre **antes × depois** de uma mudança viária numa rua comercial do centro (exemplo escolhido
pelo time: retirar o estacionamento de um dos lados). Entregue:
1. script reprodutível que baixa o trecho do OSM, gera a rede e roda os dois cenários;
2. demanda **sintética** declarada (não temos contagem real ainda) — deixe o parâmetro de volume no topo do
   arquivo, comentado, para trocar por contagem real depois;
3. **vídeo ou GIF curto** dos dois cenários lado a lado;
4. um `LEIA.md` dizendo em 10 linhas o que a simulação prova e **o que ela não prova** (sem contagem de campo
   calibrada, ela mostra o mecanismo, não o resultado).
Pasta de saída: `simulacao-sumo/` aqui dentro. Se o SUMO não estiver instalado, instale só no ambiente local.

## Tarefa 2 — Contagem em vídeo, prova mínima
Se sobrar tempo: um script que recebe **um arquivo de vídeo** de um cruzamento e devolve contagem por tipo
(carro, moto, ônibus, caminhão, bicicleta, pedestre) por bloco de 5 minutos, em CSV, **descartando o frame**
depois de contar e sem reconhecer rosto ou placa. Modelo aberto (ex.: YOLO) rodando local. Entregue com um
vídeo de teste que você mesmo grave ou baixe de fonte aberta, e diga a taxa de acerto que mediu.

## Onde estão as coisas
- `gestor.html` — painel de demonstração (7 telas)
- `pitch-3min.md` — roteiro do pitch
- `analise-360-gaps.md` — o que temos e o que falta
- `major-gote-e-simulacao.md` — pesquisa sobre a rua e sobre simulação (leia antes da tarefa 1)
- `compras-cameras-patos.md`, `concorrentes-*.md`, `cco-modelos-outras-cidades.md` — pesquisa pública
- `simcam.py` / `simcam.json` — simulação de cobertura por câmeras
- `gravacao/txt/` — transcrição do que o diretor de mobilidade disse ao time hoje
- `publico/` — o que já é público (repositório do hub)

## Quando terminar
Escreva o que fez em `ANTIGRAVITY-ENTREGA.md` nesta pasta, com: o que rodou, o comando para reproduzir, o que
ficou de fora, e os números com etiqueta. Não apague nem reescreva arquivo de outro agente.
