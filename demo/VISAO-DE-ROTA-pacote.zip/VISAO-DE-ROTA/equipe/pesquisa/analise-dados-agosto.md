# Dataset Pássaro Branco — Patos de Minas, agosto/2026

Fonte: `/home/enio/.egos/hackathon/agregados.json` (agregado do parser, conferido contra o relatório real). Totais-base: **21.174 viagens** (20.743 realizadas · 431 não realizadas), **607.258 passageiros**, **230.447,69 km executados**, **71 seções de linha** (por sentido, não as 35 linhas-mãe do enunciado).

## 1. 5 perguntas que o dado responde sozinho, hoje

1. **Onde o subsídio é mais caro por passageiro?** IPK (passageiros/km) mais baixo: JARDIM CALIFÓRNIA-N.SRA APARECIDA = 0,64 · CENTRO-RAÇÕES PATENSE = 0,74 · RAÇÕES PATENSE-CENTRO = 1,00 · CENTRO-CHÁCARAS CAIÇARAS = 1,07 (essas 4 juntas: 499 viagens, ~2,4% do total, rodando quase vazias).
2. **Onde o ônibus mais atrasa na chegada?** ALVORADA-IFTM-INDUSTRIAL: 62,03% das viagens chegam >5min atrasadas (85 viagens) · N.S. DE FATIMA-PAULISTANO-IPANEMA: 71,43% (73 viagens) · CENTRO-LIMOEIRO-ALTO DA SERRA: 42,86% (252 viagens — essa já é volume relevante, não ruído de amostra pequena).
3. **Qual a hora crítica do sistema?** 6h: 1.892 viagens, 76.101 passageiros — pico absoluto, quase o dobro de qualquer outra hora. Mas o atraso médio de partida mais alto do dia é às 13h (148,52s), não no pico de volume.
4. **Onde a lotação estoura a capacidade média?** INDUSTRIAL-I.F.T.M-ALVORADA: lotação máxima 140 vs média 51,28 (2,7x) · SUINCO-J.CALIFÓRNIA: máxima 131 vs média 30,58 (4,3x) — picos de superlotação isolados, não constantes.
5. **Como a demanda cai no fim de semana?** Segunda: 4.042 viagens / 131.393 passageiros. Domingo: 1.755 viagens / 17.142 passageiros — 7,7x menos passageiros por viagem-dia no domingo, dado que a prefeitura decerto tem, mas raramente cruzado com atraso por dia (segunda também tem o 2º atraso médio mais baixo: 78,36s, contra 91,73s de quinta).

## 2. Eixos do pitch — o que sustenta e o que não

**QUASE (quase-acidentes por câmera):** NÃO sustenta nada diretamente — 0 campos de vídeo/evento de trânsito no dataset. Sustenta indiretamente só a **priorização de onde instalar câmera**: hora 6 (76.101 pax) e as linhas de maior lotação máxima (140, 131, 133 passageiros/viagem) são candidatas por volume de exposição, não por evidência de quase-acidente.

**RUA COM MEMÓRIA (antes/depois de intervenção):** sustenta como **linha de base** (agosto/2026 é 1 mês fechado, com médias por linha/hora prontas para comparar contra um "depois"). NÃO sustenta comparação nenhuma sozinho — não há um "antes" anterior a agosto nem um "depois" ainda coletado.

**ROTA HUMANA (acessibilidade):** sustenta só como **proxy indireto**: lotação por linha (ex. INDUSTRIAL-I.F.T.M-ALVORADA com lotação média 51,28 e máxima 140) sinaliza onde embarcar é fisicamente mais difícil. NÃO sustenta nada sobre rampa, piso tátil, tempo de embarque de PCD/idoso — o campo mais próximo (`tempo_ponto_s`, tempo parado no ponto) mede o ônibus parado, não o passageiro embarcando.

**MOBIPATOS (gamificação):** sustenta forte — dá métrica real e auditável por linha (pontualidade %, IPK, atraso médio) para virar placar/pontuação ("linha mais pontual de agosto", por exemplo). NÃO sustenta rastreamento ao vivo — é relatório histórico fechado, sem feed GPS em tempo real.

## 3. 6 cruzamentos com dado público (chave de junção + risco de atribuição falsa)

1. **Velocidade comercial × malha viária (OSM)** — chave: nome do trecho/linha casado com geometria de rua. Risco: nome do trecho no relatório não é nomenclatura oficial de via — match manual, risco de confundir ruas homônimas.
2. **Atraso por hora × calendário escolar (entrada/saída de escolas)** — chave: hora do dia (picos em 6h/12h/17h) × horário de sino. Risco: atraso tem causa múltipla; atribuir exclusivamente ao fluxo escolar é atribuição causal sem prova — só é correlação de horário.
3. **Lotação × Censo/IBGE (densidade por setor censitário)** — chave: bairro-origem da linha × setor censitário. Risco: nome popular do bairro (ex. "Alto Colina") não bate 1:1 com setor oficial, e a linha atravessa vários bairros — atribuir densidade a "a linha" é simplificação.
4. **IPK baixo × valor do contrato/km pago pela prefeitura** — chave: km_executado por linha × tarifa por km do edital de concessão. Risco: esse valor não está no dataset e pode não ser público/atualizado — sem ele, "custo do subsídio" é só km rodado, não R$.
5. **Pico de atraso × chuva (INMET, estação Patos de Minas)** — chave: data+hora da viagem × registro de precipitação. Risco: 1 estação não cobre todos os bairros; atraso correlacionado com chuva não prova causa sem controlar por outros fatores (ex. hora de pico coincide).
6. **Linhas de atraso alto × acidentes/sinistros registrados** — chave: trecho+hora da linha × local+hora do sinistro. Risco: Patos de Minas provavelmente não tem um painel público tipo Infosiga-SP; boletim de ocorrência tem subnotificação e georreferência aproximada — casamento facilmente errado.

## 4. Limites honestos (confirmados no código do parser, `scripts/passaro-branco-parser.ts:51-73`)

- **1 mês só** (agosto/2026) — sem série histórica, nenhum "antes" possível hoje.
- **Sem geolocalização por viagem** — confirmado: a interface `Viagem` não tem campo lat/lon, só km_plan/km_exec agregado. Nenhuma trajetória mapeável ponto a ponto.
- **Sem identificação de passageiro** — só contagem agregada por viagem.
- **MOTORISTA existe na fonte e nunca é lido** (LGPD/P4 — decisão deliberada do parser, não descuido).
- **Lotação é proxy, não % de ocupação** — é contagem bruta de passageiros por viagem; capacidade do veículo não está no dado, então "lotação máxima 140" não diz se o ônibus tem 40 ou 140 lugares.
- **IPK tem 2 versões divergentes**: cabeçalho do relatório diz 2,74; recomputado da forma mais correta (passageiros/km por viagem) dá 2,87 — 4,74% de delta, documentado no código, não escondido.
- **431 viagens "não realizadas" medidas vs 79 declaradas no cabeçalho** — delta não resolvido; hipótese não confirmada de viagens "Extra" cobrindo o buraco, reportado como está.
- **Granularidade é por SENTIDO (71 seções), não pelas 35 linhas-mãe** do enunciado — juntar "ALTO COLINA→SANTA LUZIA" com "SANTA LUZIA→ALTO COLINA" numa linha só exige mapeamento manual que a fonte não declara.

## 5. Demo de 60 segundos para domingo

Abrir com o número que ninguém no evento vai ter: **"6h da manhã, 1.892 viagens, 76.101 passageiros — mais que a soma das duas próximas horas do dia."** Em seguida, puxar a linha mais furada: **"ALVORADA-IFTM-INDUSTRIAL: 62% das viagens chegam com mais de 5 minutos de atraso — 85 viagens medidas, não estimadas."** Fechar com a ponte pro produto: **"cada linha vira um placar de pontualidade real — é o motor que abastece o MobiPatos."** Os 3 números (1.892 · 76.101 · 62%) saem direto de `agregados.json`, sem interpretação — só citar a linha do arquivo se alguém pedir prova na hora.