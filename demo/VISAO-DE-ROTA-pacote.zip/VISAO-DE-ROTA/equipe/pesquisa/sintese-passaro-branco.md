# Dashboard Hackathon Mobilidade — Consolidado (19/09/2026)

Leitor: Enio. Decide no funcional. Nenhum item abaixo foi inferido — cada número tem origem citada.

---

## 1. O que temos AGORA, com prova

| O quê | Caminho | Comando que prova |
|---|---|---|
| Parser Pássaro Branco (agosto/2026) | `producao/egos/scripts/passaro-branco-parser.ts` | `bash scripts/passaro-branco-parser.test.sh` → 5/5 goldens, rodou contra fonte real de 19.764.386 bytes, exit=0 |
| Dataset agregado do hackathon | `~/.egos/hackathon/agregados.json` + `~/.egos/hackathon/viagens.jsonl` (9,2 MB) | gerado pelo parser acima a partir de `~/.egos/forja/2026-09-19-hackathon-passaro-branco.pdf` (1.297 páginas) |
| Gerador de HTML autocontido (motor de entrega) | `scripts/md-para-html.ts` + `templates/human-doc/casa.css` | `bun scripts/md-para-html.ts --golden` → 🟢 65/65 goldens |
| Guard Brasil (mascaramento PII/LGPD) | `packages/guard-brasil/` | `bun test packages/guard-brasil/src/guard.test.ts` → 71 pass, 0 fail, 147 expect() |
| Corpus Atomizer (padrão de atomização de relatos) | `packages/corpus-atomizer/` | `bun test packages/corpus-atomizer/test` → 212 pass, 0 fail, 624 expect() |
| Observabilidade agregada (semáforo 4 cores) | `scripts/observabilidade.ts` | rodou ao vivo → `Resumo: 🟢3 🟡1 🔴3 ⚪0`, 7 itens medidos individualmente |
| EGOS APP nativo (porta 4599) | `scripts/orquestra-viva.sh` → `egos-app.service` | `curl -sf http://127.0.0.1:4599/estado` |
| Motor de pontos/rank/leaderboard REAL (fora do tema) | `piloto/852/src/lib/gamification.ts` | 116 linhas, `POINT_VALUES` + 6 ranks + leaderboard Supabase — mecânica reaproveitável, vocabulário é de tema policial, não de ônibus |

**Não é plug-and-play**: HTML, PII, atomização e observabilidade são blocos genéricos que exigem código novo de domínio para virar peça de mobilidade — nenhum foi testado hoje contra o dataset Pássaro Branco.

---

## 2. Mecânicas de gamificação já desenhadas — prontas para reuso

Fonte: MobiPatos+ (Gemini Deep Research, 06/05/2025, 61 KB) — hoje CONCEPT (cópia local perdida, sobrevive só o resumo em `~/.egos/relatorios/2026-09-04-mobilidade-urbana-acervo.md §2.1`) — mais 3 fontes irmãs.

| Mecânica | Fonte | Status |
|---|---|---|
| Pontos por viagem/distância/off-peak/intermodal/evento | MobiPatos+ | CONCEPT |
| Desafios sazonais ("Desafios do Cerrado") | MobiPatos+ | CONCEPT |
| Emblemas com identidade local ("Conquistas Patenses") | MobiPatos+ | CONCEPT |
| Resgate em comércio/artista local (item personalizado) | MobiPatos+ | CONCEPT |
| Ranking/comunidade | MobiPatos+ | CONCEPT — em tensão com achado de pesquisa (ver abaixo) |
| Conteúdo educativo gamificado | MobiPatos+ | CONCEPT |
| Remuneração diferenciada por caminhar até o ponto | Chat ChatGPT 06/05/2025 | CONCEPT (nem chegou ao plano formal) |
| App da prefeitura: opt-in localização + tarefas + gamificação | ChatGPT 18/09 21:36, L4154 — pedido do Enio, ainda sem resposta | CONCEPT, mais recente |
| Motor de pontos/ranks/leaderboard (código real) | `852/src/lib/gamification.ts` | REAL em produção, tema errado |
| Integrar ao app municipal existente (Patos Premia, patospremia.com.br) em vez de app novo | Chat ChatGPT 06/05/2025 | Decisão já tomada em 2025, nunca implementada |

**Contraponto obrigatório, não decorativo** — pesquisa com efeito negativo comprovado (`docs/jobs/2026-09-02-live-school-gamificacao-pesquisa.md`):
- Leaderboard individual público amplia a lacuna topo/base (Domínguez et al. 2013).
- Streak diário gera ansiedade e abandono ao quebrar (Duolingo vende "freeze" pago).
- Recompensa por atividade já intrinsecamente interessante derruba motivação quando a recompensa some (Deci/Koestner/Ryan 1999, meta-análise de 128 experimentos, d=-0,40).
- Mitigação: leaderboard por TIME, esconder posição exata, reset frequente.
- Isso atinge direto a "Vitrine de Recompensas" e o "Comunidade/rankings" do MobiPatos+ — não descartar a mecânica, mas declarar o risco se for pro pitch.

**Benchmark com número real:** Duolingo — 2→3 dias de streak = +50% de impacto motivacional declarado; 200→201 dias = +0,5% (fonte: blog oficial Duolingo, citado em `~/.egos/acervo/chatgpt/originais/ChatGPT-Estudo de caso Duolingo.md`, 24/02/2026).

---

## 3. Checklist de cruzamento de dados (intelink/BRACC) aplicado a este caso

Regra-mestra: **a prova só afunila, nunca nasce no meio** (R-CADEIA-PROV-001) e **todo número publicado carrega 3 valores** — N publicado · M do universo · S que passou no filtro (R-UNIVERSO-DECLARADO-001).

1. **Inventariar as duas bases inteiras primeiro** — feito para Pássaro Branco (21.174 viagens-âncora no bruto); não feito para qualquer segunda fonte a cruzar (OSM, INMET, Censo etc.) porque nenhuma foi aberta ainda.
2. **Âncora determinística, nunca semelhança** — se cruzar linha×trecho de rua, a chave tem que ser algo estrutural (geometria/ID oficial), nunca nome de rua digitado à mão. Nenhum cruzamento foi executado hoje — item é orientação para quando alguém tentar.
3. **Método de casamento gravado no dado** (`matched_by: "id_exato"|"geo_proximidade"|"nome_aproximado"`) — não aplicável ainda, nenhum cruzamento rodou.
4. **Trilha de 5 elos** (universo bruto → ligado → processado → com critério → publicado) — hoje só temos o elo 1 e 3 preenchidos para uma fonte só (Pássaro Branco); elos 2, 4, 5 exigem uma segunda fonte que ainda não entrou.
5. **O que não foi coberto é parte do resultado** — declarado abaixo na seção 6 (divergência de 431 vs 79 "não realizadas", granularidade por sentido em vez de linha-mãe).
6. **Evidência no artefato entregue registra padrão, nunca identificador** — MOTORISTA existe na fonte e nunca é lido pelo parser (decisão deliberada, LGPD/P4); nenhuma placa/nome vai para o dashboard.
7. **Replicabilidade** — parser não tem path hardcoded de outro time; roda contra qualquer arquivo-fonte no mesmo formato.
8. **Sucesso parcial se declara** — este dashboard cobre 1 mês (agosto/2026), 1 empresa (Pássaro Branco), sem geolocalização por viagem e sem bilhetagem nominal — dito explicitamente na seção 6.

---

## 4. Capacidades do EGOS por eixo do pitch

| Eixo | Sustenta com o dado de hoje? | Capacidade EGOS aplicável |
|---|---|---|
| **QUASE** (near-miss por câmera) | Não diretamente — zero campo de vídeo/evento no dataset. Indireto: hora 6h (76.101 pax) e linhas de lotação máxima (140/131/133 pax) priorizam onde instalar câmera. | Nenhuma capacidade específica; observabilidade genérica se aplicaria a um painel de câmeras futuro. |
| **Rua com Memória** (antes/depois) | Sustenta como linha de base (agosto fechado); não sustenta comparação sozinho — falta o "antes" e o "depois". | `scripts/md-para-html.ts` (timeline como página estática, modo cebola). |
| **Rota Humana** (acessibilidade) | Só proxy indireto — lotação por linha sinaliza dificuldade de embarque; não há campo de rampa/piso tátil/tempo de PCD. | `packages/guard-brasil/` se coletar relato de cidadão com dado pessoal. |
| **MobiPatos** (gamificação) | Sustenta forte — métrica real e auditável por linha (pontualidade %, IPK, atraso médio) vira placar. | `piloto/852/src/lib/gamification.ts` (motor de pontos REAL, precisa trocar vocabulário) + `scripts/observabilidade.ts` (padrão de placar 🟢🟡🔴⚪). |
| **Plataforma aberta / commons** | Indireto — padrão de motor de monitoramento de fonte pública (`scripts/govtech-pncp-monitor.ts`, REAL como motor, CONCEPT como aplicação a mobilidade). | `packages/corpus-atomizer/` (molde de atomização de relatos, se plataforma coletar texto livre de cidadão). |

---

## 5. Padrão de observabilidade que o dashboard deve seguir

Fonte: `scripts/orquestra-viva/blocos-resposta.ts`, `scripts/md-para-html.ts`, `templates/human-doc/casa.css`.

1. **CSS único** — herdar `templates/human-doc/casa.css` (145 linhas, tokens `--surface`/`--border`/`--accent`/`--radius`), não inventar paleta.
2. **Semáforo de 4 cores, nunca 3** — 🟢 medido sem ressalva · 🟡 medido com ressalva · 🔴 medido, é problema · ⚪ NÃO-MEDIDO. Nunca inferir cor sem comando rodado no turno.
3. **Número clicável até a prova** — todo dado do painel linka para o comando/arquivo/commit que o gerou (padrão `extrairShas`/`extrairCaminhos` em `blocos-resposta.ts:95` e `:197`).
4. **Motor separado da apresentação** — um coletor puro devolvendo JSON, servido por rota HTTP; HTML consome via `fetch`. Nunca hardcodar número no HTML.
5. **Nunca inventar número ausente** — dado que não existe no disco retorna `⚪ NÃO-MEDIDO: <comando exato para medir>`, nunca `0` nem omissão silenciosa.
6. **GATE-FRESCOR-001** — se houver par `.md`+`.html`, HTML mais velho que a fonte bloqueia regeração.
7. **R-HTML-010** — todo HTML final termina o turno aberto na tela (`xdg-open <caminho-absoluto>`), nunca só citado no chat.
8. **Rodapé de proveniência obrigatório** — fonte (`.md`/script gerador) + data de geração + "regenerável a partir de X"; nunca nome pessoal, email, IP interno.

---

## 6. Números do dataset de agosto/2026 que entram no pitch (cada um com origem)

Fonte única: `~/.egos/hackathon/agregados.json`, gerado por `scripts/passaro-branco-parser.ts` a partir de `~/.egos/forja/2026-09-19-hackathon-passaro-branco.pdf` — 4 campos conferidos calculado-vs-cabeçalho (viagens, passageiros, km executado batem 0,00%; IPK diverge, ver abaixo).

- **21.174 viagens-âncora** (20.743 realizadas + 431 não realizadas) — `agregados.json:totais.viagens_total` — 🔴 as 431 não realizadas divergem das **79** declaradas no cabeçalho do relatório original; delta não resolvido (hipótese não confirmada de viagens "Extra" cobrindo parte do buraco).
- **607.258 passageiros** — `agregados.json:totais.passageiros` — 🟢 calculado bate 0,00% contra o cabeçalho do relatório.
- **230.447,69 km executados** — `agregados.json:totais.km_executado` — 🟢 bate 0,00% contra o cabeçalho.
- **231.331,62 km planejados** — `agregados.json:totais.km_planejado` — 🟢 bate 0,00% (bônus não pedido pelo gate, medido mesmo assim).
- **IPK recomputado 2,87 vs declarado no cabeçalho 2,74** — delta 4,74% — 🔴 não gated (o gate do R13 só cobre viagens/passageiros). Explicação no achado do parser: a coluna I.P.K bruta vem "-" sistematicamente em viagens de baixa lotação; média só dos valores presentes infla para 3,33 — recomputar passageiros/km por viagem reduz o delta.
- **71 seções de linha distintas** — `agregados.json:totais.linhas_distintas` — não são as 35 "linhas" do enunciado da tarefa: a granularidade real é por SENTIDO (ida+volta), ~2× 35.
- **Hora-pico: 6h, 1.892 viagens, 76.101 passageiros** — `agregados.json:totais.hora_pico` — quase o dobro da 2ª colocada em volume.
- **Atraso médio de partida 78,84s / chegada -200,88s (médias globais)** — `agregados.json:totais`.
- **Velocidade média 17,66 km/h** — `agregados.json:totais.vel_media`.
- **Pior linha em atraso: ALVORADA-IFTM-INDUSTRIAL, atraso médio de chegada 1.122,85s, 62,03% das viagens >5min atrasadas (85 viagens medidas)** — `top_linhas_atraso[0]`.
- **Linha de maior movimento: ALTO COLINA-SANTA LUZIA, 1.050 viagens, 43.152 passageiros** — `top_linhas_movimento[0]`.
- **Segunda-feira: 4.042 viagens / 131.393 passageiros vs Domingo: 1.755 viagens / 17.142 passageiros** — 7,7× menos passageiros por viagem no domingo — citado em ANÁLISE §1.5, não está em `agregados.json:totais` de topo (é quebra por dia da semana dentro do agregado).
- **Lotação: INDUSTRIAL-I.F.T.M-ALVORADA máxima 140 vs média 51,28 (2,7×); SUINCO-J.CALIFÓRNIA máxima 131 vs média 30,58 (4,3×)** — ANÁLISE §1.4 — proxy de passageiros por viagem, não % de ocupação real (capacidade do veículo não está no dado).

**Limites que vão junto com qualquer número acima, sempre:** 1 mês só (agosto/2026), sem geolocalização por viagem, sem identificação de passageiro individual, MOTORISTA nunca lido (LGPD/P4 deliberado), IPK com 2 versões divergentes documentadas no código, 431 vs 79 não realizadas sem explicação fechada.

---

## O que ficou de fora desta consolidação
Nenhum cruzamento com fonte externa (OSM, INMET, Censo, calendário escolar) foi executado — só listado como checklist na seção 3. Os 4 canvases do ChatGPT de 06/05/2025 e o texto integral do MobiPatos+ (61 KB) não foram lidos, vivem só no Google Drive. Nenhum HTML foi gerado ou aberto na tela nesta consolidação — este documento é a matéria-prima em Markdown para quem for montar o HTML com `scripts/md-para-html.ts`.

## Próxima
Rodar `scripts/md-para-html.ts` sobre este Markdown (ou sobre uma curadoria dele) para produzir o HTML final com o CSS/padrão da seção 5, e abrir na tela com `xdg-open` antes de mostrar ao Enio (R-HTML-010).