#!/usr/bin/env python3
"""build-dashboard.py — gera dashboard.html do hackathon a partir dos JSON/MD em ~/.egos/hackathon.
Determinístico: mesma entrada → mesma saída (exceto o relógio de geração no cabeçalho).
Regras herdadas: casa.css (SSOT visual), semáforo 4 cores, número clicável até a prova,
rodapé de proveniência, GATE-FRESCOR (compara mtime das fontes)."""
import json, os, re, time, hashlib, html, sys
H = os.path.expanduser('~/.egos/hackathon/')
TIME = os.environ.get('TIME_VERSAO') == '1'
CSS = open('/home/enio/enio-dev/producao/egos/templates/human-doc/casa.css').read()

def ld(n, default=None):
    p = H + n
    if not os.path.exists(p): return default
    return json.load(open(p)) if n.endswith('.json') else open(p).read()

def sha(n):
    p = H + n
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()[:12] if os.path.exists(p) else '—'

def mtime(n):
    p = H + n
    return time.strftime('%d/%m %H:%M:%S', time.localtime(os.path.getmtime(p))) if os.path.exists(p) else '⚪'

agr = ld('agregados.json', {}); perfil = ld('perfil-5min.json', {}); mapa = ld('mapa-pontos.json', {'pontos': []})
acid = ld('acidentes-pontos.json', {'ocorrencias': [], 'universo': {}}); itens = ld('dados-publicos-itens.json', [])
crit = ld('dados-publicos-critico.json', {'critico': {'lacunas': []}, 'contagem': {}}); parser = ld('parser-relatorio.json', {})
md = {k: ld(k, '') for k in ['dados-publicos-relatorio.md', 'analise-dados-agosto.md', 'acervo-gamificacao.md', 'acervo-intelink-bracc.md',
      'acervo-capacidades.md', 'acervo-observabilidade.md', 'exports-sintese.md', 'sintese-passaro-branco.md', 'BRIEFING-TIME.md', 'COORDENACAO-CODEX.md', 'editais-10-anos.md', 'cameras-e-gamificacao.md', 'afinar-a-reza.md', 'desenho-visao-de-rota.md', 'modelo-de-negocio-e-operacao.md', 'parcerias-cameras-brasil.md', 'parcerias-cameras-mundo.md', 'olho-vivo-quem-manda.md', 'base-legal-cameras.md', 'nomes-e-mensagem-publica.md']}
if TIME:
    # R-ENTREGA-PURA-001 no gerador: a versão compartilhada não embute acervo interno e passa pelo mesmo saneador do repo público
    import importlib.util
    _aqui = os.path.dirname(os.path.abspath(__file__)); _sf = os.path.join(_aqui, 'sanear-publico.py')
    _sp = importlib.util.spec_from_file_location('sanear', _sf if os.path.exists(_sf) else H + 'sanear-publico.py'); sanear = importlib.util.module_from_spec(_sp); _sp.loader.exec_module(sanear)
    _NOTA = '_Material interno do time; não entra na versão compartilhada._'
    for _k in ('acervo-capacidades.md', 'acervo-observabilidade.md', 'exports-sintese.md', 'COORDENACAO-CODEX.md', 'acervo-gamificacao.md'):
        md[_k] = _NOTA
    _regras = next((c for c in (os.path.join(_aqui, '..', 'docs', 'regras-de-cruzamento-de-dados.md'), H + 'repo/docs/regras-de-cruzamento-de-dados.md') if os.path.exists(c)), '')
    md['acervo-intelink-bracc.md'] = open(_regras).read() if os.path.exists(_regras) else _NOTA
    md = {k: sanear.sanear_texto(v) for k, v in md.items()}
    itens = sanear.sanear_itens(itens) if len(itens) > 82 else itens
    crit = sanear.sanear_lacunas_dado(crit); CSS = sanear.sanear_texto(CSS)
tele = ld('telemetria.json', {'workflows': [], 'linha_do_tempo': []})
tot = agr.get('totais', {}); pico5 = perfil.get('pico_5min', {})
porlinha = agr.get('por_linha', []); porlinha = [{'linha': k, **v} for k, v in porlinha.items()] if isinstance(porlinha, dict) else porlinha
gerado = time.strftime('%d/%m/%Y %H:%M:%S')
fontes_mtime = {n: mtime(n) for n in ['viagens.jsonl', 'agregados.json', 'perfil-5min.json', 'mapa-pontos.json', 'acidentes-pontos.json', 'dados-publicos-itens.json']}

# ── classificação das fontes públicas ──
def acesso(it):
    p = it.get('prova') or {}
    return (p.get('acesso_final') or it.get('acesso') or '').upper()
def tem_patos(i): return ((i.get('prova') or {}).get('tem_patos') or '').upper().startswith('SIM')
A = [i for i in itens if 'PUBLICO' in acesso(i) and (i.get('prova') or {}).get('confirmado') and tem_patos(i) and i.get('sobrevive') is not False]
B = [i for i in itens if i not in A and any(k in acesso(i) for k in ('LAI', 'CONVENIO', 'PROGRAMA', 'API-CHAVE', 'CADASTRO'))]
A2 = [i for i in itens if i not in A and i not in B and 'PUBLICO' in acesso(i) and (i.get('prova') or {}).get('confirmado')]
C = [i for i in itens if i not in A and i not in B and i not in A2]

def sem(it):
    p = it.get('prova') or {}
    if it.get('sobrevive') is False: return '🔴'
    if it in A and p.get('tem_patos', '').startswith('SIM'): return '🟢'
    if it in A: return '🟡'
    if it in B: return '🟡'
    return '⚪' if 'NAO-MEDIDO' in (p.get('tem_patos') or '') else '🔴'

def esc(s): return html.escape(str(s if s is not None else ''))
def br(n):
    try: return f'{int(round(n)):,}'.replace(',', '.')
    except Exception: return '⚪'

def tabela_fontes(lst, colunas):
    rows = []
    for it in lst:
        p = it.get('prova') or {}
        cab = f"{sem(it)} <b>{esc(it.get('fonte'))}</b> <span class=muted>· {esc(it.get('dono'))}</span>"
        det = (f"<p><b>O que tem:</b> {esc(it.get('o_que_tem'))}</p><p><b>Granularidade:</b> {esc(it.get('granularidade'))}</p>"
               f"<p><b>Serve para:</b> {esc(', '.join(it.get('serve_para') or []))} · <b>valor:</b> {esc(it.get('valor'))} · <b>classificação:</b> {esc(p.get('classificacao_final') or it.get('classificacao'))}</p>"
               f"<p><b>Tem Patos?</b> {esc(p.get('tem_patos'))} · <b>Cabe até 30/09?</b> {esc(p.get('cabe_ate_30_09_2026'))}</p>"
               + (f"<p><b>Caminho de pedido:</b> {esc(p.get('caminho_de_pedido'))}</p>" if p.get('caminho_de_pedido') else '')
               + (f"<details><summary>Rascunho do pedido</summary><pre>{esc(p.get('texto_do_pedido'))}</pre></details>" if p.get('texto_do_pedido') else '')
               + f"<div class=prova><b>Prova (amostra vista):</b> {esc(p.get('amostra'))}<br><b>Evidência do varredor:</b> {esc(it.get('evidencia'))}"
               + (f"<br><b>URL:</b> <a href='{esc(it.get('url'))}' target=_blank rel=noopener>{esc(it.get('url'))}</a>" if it.get('url') else '')
               + (f"<br><b>Ressalvas:</b> {esc('; '.join(p.get('ressalvas') or []))}" if p.get('ressalvas') else '')
               + (f"<br><b>Refutação adversarial:</b> " + esc(' | '.join(f"{'REFUTADO' if v.get('refutado') else 'sobreviveu'}: {v.get('motivo')}" for v in it.get('refutacoes', []))) if it.get('refutacoes') else '')
               + "</div>")
        rows.append(f"<details class=item><summary>{cab}</summary>{det}</details>")
    return ''.join(rows) or '<p class=muted>⚪ nenhum item nesta categoria</p>'

top_pax = sorted(porlinha, key=lambda r: -(r.get('passageiros') or 0))[:10]
top_atr = sorted([r for r in porlinha if (r.get('viagens') or 0) >= 50], key=lambda r: -(r.get('atraso_medio_chegada_s') or 0))[:10]
low_ipk = sorted([r for r in porlinha if (r.get('viagens') or 0) >= 20 and r.get('ipk_medio')], key=lambda r: r['ipk_medio'])[:8]
def tr_linhas(rows, campos):
    return ''.join('<tr>' + ''.join(f"<td>{esc(str(r.get(c) if not isinstance(r.get(c), float) else round(r.get(c), 1)).replace('.', ',') if isinstance(r.get(c), (int, float)) and c != 'linha' else r.get(c))}</td>" for c in campos) + '</tr>' for r in rows)

lacunas = crit.get('critico', {}).get('lacunas', [])
uni = acid.get('universo', {})
n_geo = sum(1 for p in mapa['pontos'] if p.get('lat'))
pm_h = round((perfil.get('passageiro_minutos_atraso_chegada') or 0) / 60)

DADOS = json.dumps({'perfil': perfil.get('perfil', []), 'pontos': mapa['pontos'], 'pontos5': perfil.get('pontos', {}), 'acidentes': acid.get('ocorrencias', []), 'por_hora': agr.get('por_hora', [])}, ensure_ascii=False)

simcam = ld('simcam.json', None)
def simcam_secao():
    if not simcam: return "<section class=aba id=simcam><div class=card><h2>Simulação de cobertura por câmeras</h2><p>⚪ NÃO-MEDIDO — rode simcam.py</p></div></section>"
    u, pr = simcam['universo'], simcam['premissas']
    linhas = ''.join("<tr data-n='%d'><td><b>%d</b></td><td>%d</td><td>%s%% (%d de %d)</td><td>%s%% (%d de %d)</td><td>%d de %d</td><td>%d</td></tr>" % (
        c['cameras'], c['cameras'], c['posicoes_usadas'], str(c['pct_ocorrencias']).replace('.', ','), c['ocorrencias_cobertas'], u['ocorrencias_com_coordenada'],
        str(c['pct_graves_fatais']).replace('.', ','), c['graves_fatais_cobertas'], u['graves_fatais'], c['pontos_onibus_cobertos'], u['pontos_onibus_geocodificados'], c['maquinas']) for c in simcam['cenarios'])
    botoes = ''.join("<button class=simbtn data-n='%d'>%d câmeras</button>" % (c['cameras'], c['cameras']) for c in simcam['cenarios'])
    return ("<section class=aba id=simcam><div class=card><h2>Se a cidade lesse N câmeras, quanto do que já aconteceu estaria à vista? "
        "<span style='background:#E8A33D;color:#111;border-radius:6px;padding:2px 10px;font-size:13px;vertical-align:middle'>SIMULAÇÃO</span></h2>"
        "<p>O que é <b>medido</b>: %d ocorrências de trânsito com coordenada (dado aberto do Estado, 2025 + início de 2026), %d delas graves ou fatais, e %d pontos de ônibus com coordenada. "
        "O que é <b>simulação</b>: onde as câmeras ficariam. O cálculo escolhe, uma a uma, a célula de %d m que cobre mais ocorrências ainda não cobertas num raio de %d m.</p>"
        "<div style='margin:10px 0;display:flex;gap:8px;flex-wrap:wrap'>%s</div><div id=mapaSim style='height:460px;border-radius:10px'></div><p id=simTxt style='font-weight:600'></p>"
        "<table class=t><thead><tr><th>Cenário</th><th>Posições usadas</th><th>Ocorrências num raio de %d m</th><th>Graves e fatais</th><th>Pontos de ônibus</th><th>Máquinas (premissa: %d fluxos por máquina)</th></tr></thead><tbody>%s</tbody></table>"
        "<p>🟡 <b>Como ler, e o que isto não prova.</b> Cobrir ocorrência passada não é prever a próxima. A posição é uma célula no mapa, não uma câmera que existe: a lista dos 140 pontos reais do videomonitoramento da cidade ainda não é pública, e quando chegar substitui esta escolha. "
        "O cenário de 600 usa só %d posições porque depois disso nenhuma célula acrescenta ocorrência nova — 100%% aqui é consequência do método, não resultado. "
        "Ponto de ônibus é o centro do bairro achado pelo nome (proxy), por isso quase não coincide com cruzamento. Máquinas é conta de dividir, com a premissa declarada; nenhuma medição de desempenho foi feita.</p>"
        "<p class=prova><b>Prova:</b> <code>simcam.py</code> → <code>simcam.json</code> · determinístico (mesma entrada, mesmo resultado) · %d células candidatas, %d com ganho.</p></div></section>") % (
        u['ocorrencias_com_coordenada'], u['graves_fatais'], u['pontos_onibus_geocodificados'], pr['celula_m'], pr['raio_m'], botoes, pr['raio_m'], pr['fluxos_por_maquina'], linhas, u['celulas_com_ganho'], u['celulas_candidatas'], u['celulas_com_ganho'])
SIMCAM_JS = """<script>(function(){var S=%s;if(!S)return;var m=null,camada=null;function des(n){try{if(!m){m=L.map('mapaSim').setView([-18.5789,-46.5183],13);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(m);
(JSON.parse(document.getElementById('dados').textContent).acidentes||[]).forEach(function(o){L.circleMarker([o.lat,o.lon],{radius:2,color:'#D6453D',weight:0,fillOpacity:.45}).addTo(m);});}
if(camada)m.removeLayer(camada);camada=L.layerGroup(S.posicoes.slice(0,n).map(function(p){return L.circle(p,{radius:S.premissas.raio_m,color:'#E8A33D',weight:1,fillOpacity:.25});})).addTo(m);
var c=S.cenarios.filter(function(x){return x.cameras==n})[0];document.getElementById('simTxt').textContent='SIMULAÇÃO · '+n+' câmeras: '+String(c.pct_ocorrencias).replace('.',',')+'%% das ocorrências e '+String(c.pct_graves_fatais).replace('.',',')+'%% das graves e fatais ficam a até '+S.premissas.raio_m+' m de uma posição.';
document.querySelectorAll('.simbtn').forEach(function(b){b.style.background=b.dataset.n==n?'#0B1B2B':'';b.style.color=b.dataset.n==n?'#fff':'';});setTimeout(function(){m.invalidateSize()},60);}catch(e){document.getElementById('simTxt').textContent='⚪ mapa não carregou: '+e;}}
document.querySelectorAll('.simbtn').forEach(function(b){b.addEventListener('click',function(){des(+b.dataset.n)})});
document.addEventListener('click',function(e){var a=e.target.closest('[data-t],a[href="#simcam"]');if(a)setTimeout(function(){if(document.getElementById('mapaSim').offsetParent)des(100)},200)});})();</script>"""

def md_block(k): return f"<div class=md data-md='{esc(k)}'></div><script type='text/plain' id='md-{esc(k)}'>{md[k].replace('</script>', '<\\/script>')}</script>"

page = f"""<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Hackathon Mobilidade Patos — painel do time</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<style>{CSS}
body{{display:block;padding:0 0 60px}} .wrap{{max-width:1180px;margin:70px auto 0;padding:0 18px}}
.topo{{display:flex;flex-wrap:wrap;gap:10px;align-items:center;font-size:13px;color:var(--text-muted);margin:8px 0 18px}}
.kpis{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px;margin:14px 0 22px}}
.kpi{{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:14px 16px}}
.kpi .n{{font-size:30px;font-weight:700;line-height:1.1}} .kpi .l{{font-size:13px;color:var(--text-muted);margin-top:4px}}
.kpi .p{{font-size:12px;margin-top:8px}} .kpi .p summary{{cursor:pointer;color:var(--accent)}}
.tabs{{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 16px;position:sticky;top:56px;background:var(--bg);padding:8px 0;z-index:50}}
.tabs button{{background:var(--surface);border:1px solid var(--border);border-radius:20px;padding:6px 12px;cursor:pointer;color:var(--text-primary);font-size:13px}}
.tabs button.on{{background:var(--accent);color:#fff;border-color:var(--accent)}}
section.aba{{display:none;scroll-margin-top:140px}} section.aba.on{{display:block}}
.card{{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:16px 18px;margin:0 0 14px}}
h2{{font-size:20px;margin:6px 0 10px}} h3{{font-size:16px;margin:12px 0 6px}} .muted{{color:var(--text-muted)}}
details.item{{border-bottom:1px solid var(--border);padding:8px 0}} details.item summary{{cursor:pointer}} details.item[open] summary{{margin-bottom:6px}}
.prova{{background:var(--code-bg);border-radius:var(--radius-sm);padding:8px 10px;font-size:12.5px;margin-top:6px;word-break:break-word}}
table{{width:100%;border-collapse:collapse;font-size:13.5px}} th,td{{text-align:left;padding:6px 8px;border-bottom:1px solid var(--border);vertical-align:top}} th{{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--text-muted)}}
#mapa{{height:520px;border-radius:var(--radius);border:1px solid var(--border)}} .ctl{{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:10px 0;font-size:14px}}
input[type=range]{{width:260px}} pre{{white-space:pre-wrap;font-size:12.5px;background:var(--code-bg);padding:8px;border-radius:var(--radius-sm)}}
.md h1{{font-size:20px}} .md h2{{font-size:17px;margin-top:16px}} .md h3{{font-size:15px}} .md table{{margin:8px 0}} .md p,.md li{{font-size:14.5px}} .md blockquote{{border-left:3px solid var(--accent);padding-left:10px;color:var(--text-muted)}}
.grid2{{display:grid;grid-template-columns:1fr 1fr;gap:14px}} @media(max-width:800px){{.grid2{{grid-template-columns:1fr}}}}
.bar{{display:flex;align-items:flex-end;gap:1px;height:140px;border-bottom:1px solid var(--border)}} .bar div{{flex:1;background:var(--accent);opacity:.75;min-width:2px}} .bar div.sim{{background:var(--green)}}
.tl li{{font-size:13.5px;padding:3px 0}} .tl b{{font-variant-numeric:tabular-nums}}
footer{{max-width:1180px;margin:30px auto;padding:0 18px;font-size:12.5px;color:var(--text-muted)}}
</style></head><body>
<header class="egos-header"><div class="header-logo">EGOS <span>Hackathon Cidades Inteligentes · Patos de Minas · 18–20/09/2026</span></div>
<div class="header-title">Mobilidade Urbana Inteligente e Previsível — painel do time</div>
<div class="header-actions"><button class="btn-icon" onclick="document.body.classList.toggle('dark')">🌓</button></div></header>
<div class=wrap>
<div class=topo><span>🕒 gerado {gerado} (relógio desta máquina)</span><span>🤖 Prime (Claude, sessão de hoje) · 🧑 cortes do Enio marcados</span><span>🟢 medido · 🟡 medido com ressalva · 🔴 problema · ⚪ não medido</span><span>📁 ~/.egos/hackathon/ (fora do git)</span></div>

<h1 style="font-size:24px;margin:0 0 6px">Onde as pessoas estão perdendo tempo na mobilidade de Patos — e o que já dá para provar hoje</h1>
<p class=muted>Pergunta central do time (Rafael, 19/09 09:20): <i>quais dados precisamos coletar para descobrir onde as pessoas perdem tempo e como transformar isso em ação e informação previsível?</i></p>

<div class=kpis>
<div class=kpi><div class=n>{br(tot.get('passageiros', 0))}</div><div class=l>passageiros no ônibus em agosto/2026 (mês inteiro)</div><details class=p><summary>prova</summary>Relatório de Viagens da operadora (PDF 1.297 pág., recebido no grupo 19/09 09:06) → parser determinístico → <code>agregados.json</code> · confere com o cabeçalho do relatório: delta 0,00% · sha {sha('agregados.json')}</details></div>
<div class=kpi><div class=n>{br(pm_h)} h</div><div class=l>de gente chegando atrasada no destino, em agosto (passageiro-horas de atraso na chegada)</div><details class=p><summary>prova</summary>Σ (chegada real − planejada, só quando &gt;0) × passageiros da viagem, sobre {br(tot.get('viagens', 0))} viagens → {br(perfil.get('passageiro_minutos_atraso_chegada', 0))} passageiro-minutos · <code>perfil-5min.json</code> · 🟡 ressalva: usa passageiros da viagem inteira, não quem desceu depois do atraso</details></div>
<div class=kpi><div class=n>{pico5.get('hora', '—')}</div><div class=l>o pior bloco de 5 min do dia: {pico5.get('viagens', 0)} viagens, {br(pico5.get('passageiros', 0))} passageiros, {str(pico5.get('pct_atraso_gt5', 0)).replace('.', ',')}% chegam &gt;5 min atrasadas</div><details class=p><summary>prova</summary>agrupamento por partida planejada em blocos de 5 min · <code>perfil-5min.json → pico_5min</code></details></div>
<div class=kpi><div class=n>{br(perfil.get('horas_onibus_parado_no_ponto', 0))} h</div><div class=l>de ônibus parado no ponto no mês (média 11 min por viagem)</div><details class=p><summary>prova</summary>Σ tempo_ponto_s / 3600 · coluna "TEMP. PONTO" do relatório · <code>viagens.jsonl</code></details></div>
<div class=kpi><div class=n>{br(uni.get('ocorrencias', 0))}</div><div class=l>ocorrências de trânsito com coordenada em Patos (2025 + início de 2026), {uni.get('gravidade', {}).get('FATAL', 0)} fatais — dado público SEJUSP-MG, sem REDS</div><details class=p><summary>prova</summary>dados.mg.gov.br → Banco de Vítimas de Acidente de Trânsito (CSV) → filtro município = PATOS DE MINAS + coordenada válida · <code>fontes/prova-18.csv</code>, <code>prova-19.csv</code> (sha em <code>fontes/MANIFEST.sha256</code>) · 🟡 2026 parcial: download cortado em 2 MB</details></div>
<div class=kpi><div class=n>{len(A)} / {len(itens)}</div><div class=l>fontes públicas com dado de Patos disponível AGORA, de {len(itens)} verificadas ({len(B)} só por pedido · {len(A2)} públicas sem recorte de Patos · {len(C)} sem dado/refutadas)</div><details class=p><summary>prova</summary>varredura em 7 ângulos + prova por fonte + 2 céticos por fonte de alto valor · <code>dados-publicos-itens.json</code> · refutadas: {crit.get('contagem', {}).get('refutados', '⚪')}</details></div>
</div>

<div class=tabs>
<button class=on data-t=g-time>🙏 O time e o roteiro</button><button data-t=g-dado>📊 O que o dado prova</button><button data-t=g-mapa>🗺️ Mapa e simulações</button><button data-t=g-cameras>📷 Câmeras: como, quem, lei</button><button data-t=g-fontes>📚 Fontes, editais e dinheiro</button><button data-t=g-proximos>➡️ Próximos passos</button>
</div>
<style>.sub{{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 12px}} .sub a{{font-size:12.5px;padding:4px 10px;border:1px solid var(--border);border-radius:14px;color:var(--text-muted);text-decoration:none;background:var(--surface)}} .sub a:hover{{border-color:var(--accent);color:var(--accent)}} section.aba h2{{scroll-margin-top:150px}}</style>

<section class="aba on" id=reza><div class=card>{md_block('afinar-a-reza.md')}<hr>{md_block('nomes-e-mensagem-publica.md')}</div></section>
<section class=aba id=desenho><div class=card>{md_block('desenho-visao-de-rota.md')}</div></section>
<section class=aba id=roteiro><div class=card><h2>Roteiro do fim de semana (o que falar e o que mostrar)</h2>
<h3>Pitch de 60 segundos (domingo, banca 17h)</h3>
<ol><li><b>Abrir com o número que ninguém tem:</b> "Às 6h20 da manhã, 356 ônibus saem em 5 minutos com 15 mil pessoas — e 36% chegam mais de 5 minutos atrasados."</li>
<li><b>A dor em horas:</b> "Em agosto, foram {br(pm_h)} horas de gente chegando atrasada. Isso é tempo de vida, não de trânsito."</li>
<li><b>A linha mais furada:</b> "{top_atr[0]['linha'] if top_atr else '—'}: {round((top_atr[0].get('atraso_medio_chegada_s') or 0)/60,1) if top_atr else '—'} min de atraso médio, {str(top_atr[0].get('pct_atraso_chegada_gt_5min', top_atr[0].get('pct_atraso_chegada_gt5', '—'))).replace('.', ',') if top_atr else '—'}% das viagens."</li>
<li><b>O mecanismo:</b> "Cruzamos o relatório da operadora com dado público de acidentes e a malha da cidade. Sem câmera nova, sem app novo: as fontes já existem, o que faltava era ligar."</li>
<li><b>A ação:</b> "Com esse mapa, a cidade decide: escalonar a entrada das 20 maiores empresas em janelas de 5 min, dar ponto e horário fixo a cada ônibus da UNIPAM, priorizar onde pôr câmera. Medimos o antes, medimos o depois."</li>
<li><b>Fecho:</b> "Uma cidade não fica inteligente quando instala sensor. Fica quando consegue provar o que funcionou."</li></ol>
<h3>Agenda</h3><ul><li><b>Sáb 19/09</b> — 9h10 workshop Validação do Problema · 15h workshop MVP · mentorias o dia todo → usar para PEDIR dado aos parceiros (Prefeitura/SEBRAE/UNIPAM/UFU são organizadores; ver aba Fontes → "peça no evento").</li><li><b>Dom 20/09</b> — 13h30 pré-pitch · <b>16h prazo final</b> · 17h banca · 18h premiação (R$ 5.000 / 3.500 / 1.500).</li></ul>
<h3>O que já está pronto para mostrar</h3><ul><li>Painel com dado real de agosto (esta página).</li><li>Mapa de calor: passageiros por ponto e hora + acidentes georreferenciados (público).</li><li>Simulador de horário escalonado (5 a 30 min).</li><li>Peça de coleta pela população já existe (Senso Urbano: 1 URL, sem app, vira mapa de calor) — trocar o vocabulário de "fedor" para "onde perdi tempo".</li></ul>
<h3>O que NÃO dizer</h3><ul><li>Nada de dado da polícia (REDS/PCMG) — corte do Osair. Os acidentes aqui são SEJUSP-MG, público.</li><li>Nada de "100%", "único", "garantido". O FORJA guarda e mostra eventos; ainda não enxerga vídeo (README ago/2026).</li><li>Nomes de cliente, valores do EGOS, caminhos internos.</li></ul></div></section>

<section class=aba id=blocos><div class=card><h2>Os 5 blocos de pesquisa do time (Rafael) — o que temos, o que falta, quem tem</h2>
<table><tr><th>Bloco</th><th>Temos hoje</th><th>Falta</th><th>Quem tem / como pedir</th></tr>
<tr><td><b>1. Trânsito e semáforos</b></td><td>🟡 Piloto de semáforo com IA na Av. Paracatu (7 câmeras, 2 cruzamentos, 36 de 76 equipamentos, 60 dias desde 18/08) — só notícia, sem série numérica · velocidade média por linha de ônibus (proxy de fluidez do trecho)</td><td>Contagem veicular por hora/via · onda verde real · fila</td><td>Prefeitura (SMTT) + fornecedor do piloto — pedir no evento o agregado por hora/tipo (sem imagem/placa); PAITT etapas II/III (Líder Engenharia) tem contagem e OD de 2023</td></tr>
<tr><td><b>2. Transporte público</b></td><td>🟢 Relatório de viagens ago/2026 completo: atraso, tempo no ponto, velocidade, passageiros, IPK por viagem (21.174) · tarifa R$3 × técnica (subsídio)</td><td>GPS em tempo real · série de outros meses (antes/depois) · capacidade do veículo</td><td>Operadora (Pássaro Branco) + M2M (app "Meu Ônibus") — pedir GTFS/realtime; meses anteriores do mesmo relatório</td></tr>
<tr><td><b>3. Câmeras e dados</b></td><td>🟡 Olho Vivo: 240 câmeras/140 pontos (notícia); FORJA recebe/guarda eventos (REAL) mas não detecta ainda (CONCEPT)</td><td>Lista dos 140 pontos · fluxo agregado por ponto · acesso a stream/frames para contagem</td><td>Prefeitura (SECTEL) + Consep — pedido presencial + LAI (20+10 dias não cabe sozinho)</td></tr>
<tr><td><b>4. Informação ao cidadão</b></td><td>🟢 Perfil de demanda por 5 min (esta página) · 🟢 Senso Urbano (coleta por URL, sem app) · Patos Premia existe (app da prefeitura)</td><td>Painel/telão público · canal oficial (PatoZap) integrado</td><td>Prefeitura — propor no evento o painel com o dado que já existe</td></tr>
<tr><td><b>5. IA, segurança e privacidade</b></td><td>🟢 1.100 ocorrências georreferenciadas (SEJUSP-MG, público) · RENAEST 22.709 sinistros/140 óbitos 2018-26 · frota 136.300 veículos, 43.319 motos · Guard Brasil (PII/LGPD) · método TTC/PET para quase-acidente</td><td>Quase-acidente (nenhuma fonte pública registra) · Waze for Cities (adesão da prefeitura)</td><td>Waze for Cities: formulário institucional, sem SLA; câmera com detector local + evento sem rosto/placa (privacy by design)</td></tr></table>
<h3>Briefing do time (texto do Rafael)</h3>{md_block('BRIEFING-TIME.md')}</div></section>

<section class=aba id=mapa><div class=card><h2>Mapa de calor de Patos de Minas</h2>
<div class=ctl><label><input type=radio name=camada value=pax checked> Passageiros de ônibus por ponto</label><label><input type=radio name=camada value=acid> Acidentes com vítima (SEJUSP-MG, público)</label>
<label>hora: <input type=range id=hora min=0 max=23 value=6> <b id=horaTxt>06h</b></label><label><input type=checkbox id=todas> todas as horas</label></div>
<div id=mapa></div>
<p class=muted style="margin-top:8px">🟡 Passageiros: {n_geo} de {len(mapa['pontos'])} pontos nomeados nas linhas foram geocodificados (OpenStreetMap/Nominatim); os passageiros de cada viagem são divididos igualmente entre origem/destino/paradas nomeadas — é calor de <i>demanda por região</i>, não trajetória. Sem coordenada: {esc(', '.join(p['ponto'] for p in mapa['pontos'] if not p.get('lat')))}. · Acidentes: {uni.get('ocorrencias', 0)} ocorrências ({uni.get('vitimas_geo', 0)} vítimas), 2025 completo + 2026 parcial, coordenadas SIRGAS2000 do próprio dado. Mapa base: CARTO/OSM (precisa de internet).</p></div></section>

<section class=aba id=escalonar><div class=card><h2>Horário escalonado: distribuir a entrada das empresas em janelas de 5 min</h2>
<p>Ideia do time (Enio, 19/09): investigar horário de entrada, saída e almoço das empresas e escalonar em janelas de 5 em 5 minutos, até 30 min, para achatar o pico. O simulador abaixo usa a demanda real de ônibus por bloco de 5 min (agosto/2026) e desloca uma fração dos passageiros do pico para blocos seguintes.</p>
<div class=ctl><label>faixa: <select id=faixa><option value="300-540">manhã 05:00–09:00</option><option value="660-840">almoço 11:00–14:00</option><option value="960-1140">tarde 16:00–19:00</option></select></label>
<label>empresas participando: <input type=range id=frac min=0 max=100 value=40> <b id=fracTxt>40%</b></label>
<label>espalhar até: <input type=range id=jan min=5 max=30 step=5 value=20> <b id=janTxt>20 min</b></label></div>
<div class=grid2><div><h3>Hoje (medido)</h3><div class=bar id=barHoje></div><p id=hojeTxt class=muted></p></div><div><h3>Simulado</h3><div class=bar id=barSim></div><p id=simTxt class=muted></p></div></div>
<h3>No mapa da cidade: carga no pior bloco de 5 min, por ponto</h3>
<div class=ctl><label><input type=radio name=escMapa value=hoje checked> hoje</label><label><input type=radio name=escMapa value=sim> simulado</label><span class=muted>🟢 até 40% do pico da cidade · 🟡 40–70% · 🔴 acima de 70% (o pico é o maior valor de "hoje", fixo, para os dois mapas serem comparáveis)</span></div>
<div id=mapaEsc style="height:480px;border-radius:var(--radius);border:1px solid var(--border)"></div>
<p class=muted id=mapaEscTxt></p>
<p class=muted>🟡 Modelo simples e declarado: a fração escolhida dos passageiros de cada bloco de pico é distribuída uniformemente nos blocos seguintes até a janela. Não modela capacidade de via nem elasticidade; serve para mostrar a ordem de grandeza do achatamento. Os empregadores já aparecem nos nomes das linhas (Suinco, Gazin, Predilecta, Pró-Curar-Se, Cemil, Rações Patense, IFTM, UNIPAM) — a lista de empresas com horário de entrada é o dado a coletar com elas (ver Próximos passos).</p></div></section>

<section class=aba id=unipam><div class=card><h2>Ônibus da UNIPAM: chegada escalonada e ponto fixo por ônibus</h2>
<p>Ideia do time (Enio, 19/09): verificar com câmeras os horários de chegada dos ônibus (fretados/universitários) da UNIPAM na cidade; distribuir as chegadas com intervalo mínimo de 5 min; estabelecer um local específico de parada para cada ônibus.</p>
<table><tr><th>Passo</th><th>O que precisa</th><th>Temos?</th><th>Quem tem</th></tr>
<tr><td>1. Lista dos ônibus que chegam à UNIPAM (linha, cidade de origem, horário previsto, ponto onde para hoje)</td><td>grade de fretamento + linhas urbanas que passam pela UNIPAM (no relatório: "N.SRA. DE FATIMA - STA. HELENA - UNIPAM - IPANEMA" e "ALVORADA - UNIPAM - PREDILECTA - INDUSTRIAL")</td><td>🟡 só as 2 linhas urbanas medidas; fretados ⚪</td><td>UNIPAM (setor de transporte/ouvidoria) e empresas de fretamento — parceiro do evento, pedir no sábado</td></tr>
<tr><td>2. Medir chegada real por câmera</td><td>1 câmera fixa no acesso + contagem de ônibus por minuto (detector local, sem placa)</td><td>🟡 FORJA recebe eventos; detector ainda por ligar (Frigate/YOLO)</td><td>Olho Vivo tem câmera no entorno? (lista dos 140 pontos — pedir)</td></tr>
<tr><td>3. Escalonar: ≥5 min entre chegadas, 1 vaga por ônibus</td><td>tabela editável (abaixo) + mapa dos pontos de parada</td><td>🟢 esqueleto pronto nesta página</td><td>decisão UNIPAM + SMTT</td></tr>
<tr><td>4. Medir o depois</td><td>mesma câmera, mesma métrica, 2 semanas</td><td>⚪</td><td>—</td></tr></table>
<h3>Esqueleto do escalonamento (edite direto na tabela)</h3>
<table id=tabUnipam contenteditable=true><tr><th>Ônibus</th><th>Origem</th><th>Chegada hoje</th><th>Chegada proposta</th><th>Ponto de parada</th><th>Observação</th></tr>
<tr><td>1</td><td>(ex.: Carmo do Paranaíba)</td><td>18:45</td><td>18:40</td><td>Vaga A — Rua Major Gote, frente ao bloco X</td><td>⚪ a confirmar</td></tr>
<tr><td>2</td><td></td><td>18:45</td><td>18:45</td><td>Vaga B</td><td></td></tr>
<tr><td>3</td><td></td><td>18:50</td><td>18:50</td><td>Vaga C</td><td></td></tr>
<tr><td>4</td><td></td><td>18:50</td><td>18:55</td><td>Vaga D</td><td></td></tr></table>
<p class=muted>⚪ Os horários acima são exemplo de formato, não medição. A regra proposta: nenhuma chegada a menos de 5 min da anterior; cada ônibus tem vaga nomeada; desvio &gt;5 min vira evento na timeline.</p></div></section>

<section class=aba id=onibus><div class=card><h2>O que o dado da operadora (agosto/2026) prova</h2>
<div class=grid2><div><h3>Linhas com mais passageiros</h3><table><tr><th>Linha (sentido)</th><th>Viagens</th><th>Passageiros</th><th>IPK</th><th>Atraso méd. chegada (s)</th></tr>{tr_linhas(top_pax, ['linha', 'viagens', 'passageiros', 'ipk_medio', 'atraso_medio_chegada_s'])}</table></div>
<div><h3>Linhas que mais atrasam na chegada (≥50 viagens)</h3><table><tr><th>Linha (sentido)</th><th>Viagens</th><th>Atraso méd. (s)</th><th>% &gt;5 min</th><th>Passageiros</th></tr>{tr_linhas(top_atr, ['linha', 'viagens', 'atraso_medio_chegada_s', 'pct_atraso_chegada_gt_5min', 'passageiros'])}</table></div></div>
<h3>Linhas rodando mais vazias (IPK baixo = subsídio caro por passageiro)</h3><table><tr><th>Linha (sentido)</th><th>Viagens</th><th>IPK</th><th>Passageiros</th><th>km</th></tr>{tr_linhas(low_ipk, ['linha', 'viagens', 'ipk_medio', 'passageiros', 'km_exec'])}</table>
<h3>Demanda e atraso por hora</h3><div class=bar id=barHora></div><p class=muted id=barHoraTxt></p>
<h3>Análise completa (braço de análise, com limites declarados)</h3>{md_block('analise-dados-agosto.md')}
<h3>Conferência do parser</h3><pre>{esc(parser.get('conferencia', '⚪'))}</pre><p class=muted>goldens: {esc(parser.get('goldens', '⚪'))}</p></div></section>

<section class=aba id=fontes><div class=card><h2>Fontes de dados: o que temos, o que falta e por quem chegar</h2>
<p class=muted>Universo: {len(itens)} fontes verificadas (7 ângulos: federal, MG, município, privado/crowd, câmeras, acadêmico, acervo local) · cada uma aberta de verdade · as de alto valor passaram por 2 céticos · {crit.get('contagem', {}).get('refutados', 0)} refutadas.</p>
<h3>🟢 Temos hoje — público, com dado de Patos ({len(A)})</h3>{tabela_fontes(A, None)}
<h3>🟡 Falta, mas alguém tem — com caminho de pedido ({len(B)})</h3>{tabela_fontes(B, None)}
<h3>🟡 Público e aberto, mas sem recorte de Patos (contexto/benchmark) ({len(A2)})</h3>{tabela_fontes(A2, None)}
<h3>⚪/🔴 Não existe, não abriu ou refutado ({len(C)})</h3>{tabela_fontes(C, None)}
<h3>Lacunas apontadas pelo crítico de completude ({len(lacunas)})</h3><ul>{''.join(f"<li><b>{esc(l.get('lacuna'))}</b> — {esc(l.get('como_fechar_hoje'))} <span class=muted>({esc(l.get('serve_para'))})</span></li>" for l in lacunas)}</ul>
<h3>Relatório completo da varredura</h3>{md_block('dados-publicos-relatorio.md')}</div></section>

<section class=aba id=editais><div class=card><h2>Editais e municípios de referência em mobilidade (10 anos) — Eagle Eye + Querido Diário + rankings</h2>{md_block('editais-10-anos.md') if md.get('editais-10-anos.md') else '<p class=muted>⚪ em processamento — workflow wf_5c24330a-1ec</p>'}</div></section>
{simcam_secao()}<section class=aba id=cameras><div class=card>{md_block('cameras-e-gamificacao.md')}</div></section>
<section class=aba id=gamif><div class=card><h2>Gamificação: o que já foi desenhado (MobiPatos+) e o que o dado de agosto permite</h2><p class=muted>A versão reduzida ao app que já existe (Conecta Patos) está na aba 📷 Câmeras inteligentes, 2ª seção.</p>
<p>Pedido do Enio (18/09 21:36, de dentro do evento): convidar as pessoas a instalar o app da prefeitura, compartilhar localização, concluir tarefas e ganhar — para medir mais e aumentar o uso. Já existe plano (MobiPatos+, Gemini 06/05/2025) com 6 pilares; com o relatório de agosto, o placar por linha (pontualidade, IPK) vira métrica real e auditável.</p>{md_block('acervo-gamificacao.md')}</div></section>

<section class=aba id=startup><div class=card><h2>Que startup/inovação é essa?</h2>
<p><b>Pergunta do Enio (19/09 09:40):</b> seria de consultorias que dependem dos dados para ação em cima deles? Talvez isso seja o principal.</p>
<p><b>Leitura:</b> a inovação não é o app nem o sensor — é a <b>camada que transforma dado em decisão com dono e com medição antes/depois</b>. Três produtos na mesma tecnologia:</p>
<table><tr><th>Produto</th><th>Quem paga</th><th>O que entrega</th><th>Como se cobra</th></tr>
<tr><td><b>Diagnóstico de tempo perdido</b> (consultoria orientada a dado)</td><td>Prefeitura (SMTT), operadora, UNIPAM, grandes empregadores</td><td>onde se perde tempo, com número; plano de ação (escalonar horários, ponto fixo por ônibus, onde pôr câmera)</td><td>projeto fechado + êxito sobre a redução medida (baseline assinado antes)</td></tr>
<tr><td><b>Motor de medição</b> (o que a consultoria usa)</td><td>a própria consultoria; depois licenciado à cidade</td><td>parser de relatórios, cruzamento com dado público, mapa/painel, coleta pela população (Senso Urbano), timeline antes/depois</td><td>assinatura por cidade/órgão</td></tr>
<tr><td><b>Commons aberto</b> (federação de projetos do hackathon)</td><td>ninguém no início; bounties de quem tiver problema</td><td>código/dados abertos com autoria e proveniência; problemas com critério de aceite e recompensa</td><td>serviço de implantação e suporte é contratado; o código é livre</td></tr></table>
<p><b>Trade-off honesto:</b> consultoria escala devagar e depende de gente; o que escala é o motor. Vender a decisão, entregar o motor — e o Commons garante que a ideia de outro time não morre domingo. Nem toda cidade é camada 2 ou 3; no início a maioria é camada 1 (projeto fechado).</p>
<p class=muted>Coerente com o que já está escrito no EGOS: preço tem camada (execução direta · sistema interconectado · êxito sobre aumento gerado, só com baseline declarado antes).</p></div></section>

<section class=aba id=modelo><div class=card>{md_block('modelo-de-negocio-e-operacao.md')}</div></section>
<section class=aba id=olhovivo><div class=card>{md_block('olho-vivo-quem-manda.md')}</div></section>
<section class=aba id=legal><div class=card>{md_block('base-legal-cameras.md')}</div></section>
<section class=aba id=parcerias><div class=card><h2>Onde isso já acontece (set/2026)</h2><p><b>Moldes para Patos:</b> Porto Alegre (termo de cooperação EPTC↔SSP-RS: 116 câmeras de trânsito + 365 de segurança compartilhadas) · Vitória/ES (contagem de fluxo e origem-destino do cerco eletrônico) · COR-Rio (contagem por tipo/hora, acordo acadêmico LNCC/CEFET) · Bellevue-EUA (near-miss com 100 câmeras CCTV existentes, −42% de conflitos veículo-pedestre) · Amsterdã (contagem agregada em blocos de 5 min, GDPR) · Fortaleza (câmera semafórica conta e não grava). <b>O que derruba projeto:</b> reconhecimento facial (Clearview: ~€105 mi em multas; AI Act art. 5; San Francisco baniu) e licitação sem justificativa técnica (TCE-SC suspendeu R$ 122 mi em Joinville; TCE-PR R$ 23,7 mi). Conclusão: o desenho "contar, classificar, sem rosto e sem placa, processado na origem" é o que passa.</p>{md_block('parcerias-cameras-brasil.md')}<hr>{md_block('parcerias-cameras-mundo.md')}</div></section>
<section class=aba id=regras><div class=card><h2>Regras de cruzamento de dados e investigação aplicadas a este caso</h2>{md_block('acervo-intelink-bracc.md')}
<h3>Capacidades do EGOS que servem ao hackathon</h3>{md_block('acervo-capacidades.md')}</div></section>

<section class=aba id=proximos><div class=card><h2>Próximos passos — sábado e domingo</h2>
<h3>Peça no evento (Prefeitura, SEBRAE, UNIPAM, UFU e Patos Valley são organizadores — pedido presencial vale mais que LAI)</h3>
<ol><li><b>UNIPAM</b> — grade dos ônibus fretados (origem, horário, ponto) e um ponto de câmera no acesso.</li><li><b>Prefeitura/SMTT</b> — contagem por hora/tipo do piloto de semáforo da Av. Paracatu (agregado, sem imagem) e a lista dos 140 pontos do Olho Vivo.</li><li><b>Prefeitura</b> — etapas II/III do PAITT (contagem volumétrica e pesquisa origem-destino, 2023).</li><li><b>Operadora</b> — os mesmos relatórios de viagem de maio a julho (para ter o "antes") e o GTFS do app "Meu Ônibus".</li><li><b>20 maiores empregadores</b> (os das linhas: Suinco, Gazin, Predilecta, Pró-Curar-Se, Cemil, Rações Patense + IFTM/UNIPAM) — horário de entrada, saída e almoço, número de funcionários por turno.</li><li><b>SEBRAE</b> — regulamento e critérios da banca (não estão na página).</li></ol>
<h3>Construir até domingo 16h</h3><ol><li>Fechar o mapa: geocodificar os {len(mapa['pontos']) - n_geo} pontos que faltaram; trocar tiles online pelo mapa offline de Patos (pmtiles do Senso Urbano).</li><li>Senso Urbano com vocabulário de mobilidade: "onde perdi tempo hoje?" (1 URL, sem app) — QR no oCEANo para o time e a plateia alimentarem o mapa ao vivo.</li><li>Escalonador com a lista real de empresas (item 5 acima).</li><li>Timeline antes/depois (Rua com Memória) com os meses anteriores, se a operadora entregar.</li><li>Commons: esqueleto local (README, CONTRIBUTING, bounties) — a cargo do Codex; publicar é ato do Enio.</li></ol>
<h3>Pendências de segurança e sistema (não são do hackathon, mas apareceram hoje)</h3><ul><li>🔴 Uma API key do TypeSafe/Jev foi colada em texto puro num chat do ChatGPT (18/09) — rotacionar.</li><li>🟡 Freio "só quando marcado" do WhatsApp está ativo no disco, não commitado (produção 23 commits à frente da origin, teto 5 — reconciliação pendente).</li></ul>
<h3>Coordenação com o Codex</h3>{md_block('COORDENACAO-CODEX.md')}</div></section>

<section class=aba id=tele><div class=card><h2>Telemetria e observabilidade desta pesquisa</h2>
<h3>Linha do tempo (relógio local)</h3><ul class=tl>{''.join(f"<li><b>{esc(e.get('hora'))}</b> {esc(e.get('origem'))} {esc(e.get('evento'))}</li>" for e in tele.get('linha_do_tempo', []))}</ul>
<h3>Braços de pesquisa (workflows)</h3><table><tr><th>Workflow</th><th>Agentes</th><th>Tokens</th><th>Duração</th><th>Resultado</th></tr>{''.join(f"<tr><td>{esc(w.get('nome'))}<br><span class=muted>{esc(w.get('id'))}</span></td><td>{esc(w.get('agentes'))}</td><td>{esc(w.get('tokens'))}</td><td>{esc(w.get('duracao'))}</td><td>{esc(w.get('resultado'))}</td></tr>" for w in tele.get('workflows', []))}</table>
<h3>Arquivos-fonte desta página (frescor)</h3><table><tr><th>Arquivo</th><th>Modificado</th><th>sha256 (12)</th></tr>{''.join(f"<tr><td><code>{n}</code></td><td>{fontes_mtime[n]}</td><td>{sha(n)}</td></tr>" for n in fontes_mtime)}</table>
<p class=muted>Arquivos externos baixados: <code>fontes/MANIFEST.sha256</code> ({len(open(H + 'fontes/MANIFEST.sha256').read().splitlines()) if os.path.exists(H + 'fontes/MANIFEST.sha256') else 0} arquivos).</p>
<h3>Padrão herdado</h3>{md_block('acervo-observabilidade.md')}
<h3>Atualização lida dos chats do ChatGPT (59 exports, leitura integral)</h3>{md_block('exports-sintese.md')}</div></section>
</div>
<footer>Gerado por <code>~/.egos/hackathon/build-dashboard.py</code> em {gerado} a partir dos arquivos listados em Telemetria; regenerável com <code>python3 build-dashboard.py</code>. Fora do git de propósito (dado de grupo e de parceiro). Dado da polícia (REDS/PCMG) não entra — corte do Osair, 02/09.</footer>
<script id=dados type=application/json>{DADOS}</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.heat/0.2.0/leaflet-heat.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/marked/12.0.2/marked.min.js"></script>
<script>
const D=JSON.parse(document.getElementById('dados').textContent);
document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>{{document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('on'));b.classList.add('on');document.querySelectorAll('section.aba').forEach(s=>s.classList.toggle('on',s.id===b.dataset.t));if(b.dataset.t==='g-mapa'){{setTimeout(()=>{{if(window._map)window._map.invalidateSize();desenhaEsc();}},80);}}}});
const h0=location.hash.slice(1);if(h0){{let b0=document.querySelector('.tabs button[data-t="'+h0+'"]');if(!b0){{const el=document.getElementById(h0);const sec=el&&el.closest('section.aba');if(sec)b0=document.querySelector('.tabs button[data-t="'+sec.id+'"]');}}if(b0)b0.click();}}
document.querySelectorAll('.sub a').forEach(a=>a.onclick=e=>{{e.preventDefault();const el=document.getElementById(a.getAttribute('href').slice(1));if(el)el.scrollIntoView({{behavior:'smooth',block:'start'}});}});
document.querySelectorAll('.md').forEach(el=>{{const s=document.getElementById('md-'+el.dataset.md);if(s&&window.marked)el.innerHTML=marked.parse(s.textContent);}});
// ── mapa ──
let map,heat;try{{map=L.map('mapa').setView([-18.5789,-46.5183],13);window._map=map;
const osm=L.tileLayer('https://tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png',{{attribution:'© OpenStreetMap',maxZoom:19,referrerPolicy:'no-referrer'}}).addTo(map);let falhas=0;osm.on('tileerror',()=>{{if(++falhas===3){{map.removeLayer(osm);L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{{z}}/{{y}}/{{x}}',{{attribution:'© Esri, OpenStreetMap contributors',maxZoom:19}}).addTo(map);}}}});
const marcadores=L.layerGroup().addTo(map);
function desenha(){{const cam=document.querySelector('input[name=camada]:checked').value;const h=+document.getElementById('hora').value;const todas=document.getElementById('todas').checked;document.getElementById('horaTxt').textContent=String(h).padStart(2,'0')+'h';
if(heat)map.removeLayer(heat);marcadores.clearLayers();let pts=[];
if(cam==='pax'){{let mx=1;const rows=D.pontos.filter(p=>p.lat).map(p=>{{const v=todas?p.pax_total:(p.pax_por_hora[String(h)]||0);mx=Math.max(mx,v);return [p,v];}});
rows.forEach(([p,v])=>{{if(v>0){{pts.push([p.lat,p.lon,v/mx]);L.circleMarker([p.lat,p.lon],{{radius:4+18*Math.sqrt(v/mx),color:'#8A5F1C',weight:1,fillOpacity:.25}}).bindTooltip(p.ponto+': '+Math.round(v).toLocaleString('pt-BR')+' passageiros'+(todas?' no mês':' às '+String(h).padStart(2,'0')+'h')+' · '+p.secoes+' linhas').addTo(marcadores);}}}});
heat=L.heatLayer(pts,{{radius:45,blur:35,maxZoom:15}}).addTo(map);}}
else{{const oc=D.acidentes;oc.forEach(o=>{{const w=o.pior==='FATAL'?1:o.pior==='GRAVE'?.6:.3;pts.push([o.lat,o.lon,w]);if(o.pior!=='LEVE')L.circleMarker([o.lat,o.lon],{{radius:o.pior==='FATAL'?7:5,color:o.pior==='FATAL'?'#A93226':'#c77d2b',weight:1,fillOpacity:.6}}).bindTooltip(o.pior+' · '+o.ano+'-'+String(o.mes).padStart(2,'0')+' · '+o.vitimas+' vítima(s) · '+o.tipos.join(', ')).addTo(marcadores);}});
heat=L.heatLayer(pts,{{radius:22,blur:18,maxZoom:16}}).addTo(map);}}}}
document.querySelectorAll('input[name=camada],#hora,#todas').forEach(e=>e.addEventListener('input',desenha));desenha();}}catch(e){{document.getElementById('mapa').innerHTML='<p style=padding:20px>⚪ mapa não carregou (sem internet para Leaflet/tiles?): '+e+'</p>';}}
// ── barras por hora ──
(function(){{const ph=D.por_hora||[];const mx=Math.max(1,...ph.map(x=>x.passageiros||0));const el=document.getElementById('barHora');ph.forEach(x=>{{const d=document.createElement('div');d.style.height=(100*(x.passageiros||0)/mx)+'%';d.title=String(x.hora).padStart(2,'0')+'h: '+(x.passageiros||0).toLocaleString('pt-BR')+' passageiros · '+x.viagens+' viagens · atraso médio partida '+(x.atraso_medio_partida_s==null?'⚪':Math.round(x.atraso_medio_partida_s)+'s');el.appendChild(d);}});const p=ph.reduce((a,b)=>(b.passageiros||0)>(a.passageiros||0)?b:a,{{}});document.getElementById('barHoraTxt').textContent='0h → 23h. Pico: '+String(p.hora).padStart(2,'0')+'h com '+(p.passageiros||0).toLocaleString('pt-BR')+' passageiros em '+p.viagens+' viagens. Passe o mouse para ver cada hora.';}})();
// ── escalonador ──
function sim(){{const [a,b]=document.getElementById('faixa').value.split('-').map(Number);const f=+document.getElementById('frac').value/100;const jan=+document.getElementById('jan').value;document.getElementById('fracTxt').textContent=Math.round(f*100)+'%';document.getElementById('janTxt').textContent=jan+' min';
const P=D.perfil.filter(x=>x.min>=a&&x.min<b);const hoje=P.map(x=>x.passageiros);const n=hoje.length;const s=hoje.slice();const media=hoje.reduce((x,y)=>x+y,0)/n;
const k=jan/5;for(let i=0;i<n;i++){{if(hoje[i]>media){{const mov=(hoje[i]-media)*f;s[i]-=mov;for(let j=1;j<=k;j++){{if(i+j<n)s[i+j]+=mov/k;}}}}}}
const mx=Math.max(...hoje,...s);function draw(id,arr,cls){{const el=document.getElementById(id);el.innerHTML='';arr.forEach((v,i)=>{{const d=document.createElement('div');if(cls)d.className=cls;d.style.height=(100*v/mx)+'%';d.title=P[i].hora+': '+Math.round(v).toLocaleString('pt-BR')+' passageiros';el.appendChild(d);}});}}
draw('barHoje',hoje,'');draw('barSim',s,'sim');const pk=Math.max(...hoje),ps=Math.max(...s);
document.getElementById('hojeTxt').textContent='Pico de '+Math.round(pk).toLocaleString('pt-BR')+' passageiros em 5 min ('+P[hoje.indexOf(pk)].hora+').';
document.getElementById('simTxt').textContent='Pico cai para '+Math.round(ps).toLocaleString('pt-BR')+' ('+Math.round(100*(1-ps/pk))+'% menor) com '+Math.round(f*100)+'% das empresas escalonando até '+jan+' min. Total de passageiros igual: '+Math.round(s.reduce((x,y)=>x+y,0)).toLocaleString('pt-BR')+'.';}}
document.querySelectorAll('#faixa,#frac,#jan').forEach(e=>e.addEventListener('input',sim));sim();
// ── mapa do escalonamento: por ponto, carga hoje × simulada ──
let mapaEsc,camadaEsc;
function simPonto(serie,f,k){{const n=serie.length;const s=serie.slice();const media=serie.reduce((x,y)=>x+y,0)/n;for(let i=0;i<n;i++){{if(serie[i]>media){{const mov=(serie[i]-media)*f;s[i]-=mov;for(let j=1;j<=k;j++){{if(i+j<n)s[i+j]+=mov/k;}}}}}}return s;}}
function desenhaEsc(){{try{{if(!mapaEsc){{mapaEsc=L.map('mapaEsc').setView([-18.5789,-46.5183],13);L.tileLayer('https://tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png',{{attribution:'© OpenStreetMap',maxZoom:19}}).addTo(mapaEsc);camadaEsc=L.layerGroup().addTo(mapaEsc);}}
const [a,b]=document.getElementById('faixa').value.split('-').map(Number);const f=+document.getElementById('frac').value/100;const k=+document.getElementById('jan').value/5;const modo=document.querySelector('input[name=escMapa]:checked').value;
const blocos=[];for(let m=a;m<b;m+=5)blocos.push(String(m));
camadaEsc.clearLayers();const linhas=[];let picoCidade=1;
D.pontos.filter(p=>p.lat).forEach(p=>{{const serie=blocos.map(x=>(D.pontos5[p.ponto]||{{}})[x]||0);const hoje=Math.max(...serie);picoCidade=Math.max(picoCidade,hoje);linhas.push({{p,serie,hoje}});}});
let soma=0,somaS=0;
linhas.forEach(({{p,serie,hoje}})=>{{const sim=Math.max(...simPonto(serie,f,k));const v=modo==='hoje'?hoje:sim;soma+=hoje;somaS+=sim;const r=v/picoCidade;const cor=r>0.7?'#A93226':r>0.4?'#c98a1b':'#2F7D4F';
L.circleMarker([p.lat,p.lon],{{radius:6+22*Math.sqrt(r),color:cor,weight:1.5,fillColor:cor,fillOpacity:.45}}).bindTooltip(p.ponto+': pior bloco '+Math.round(hoje).toLocaleString('pt-BR')+' hoje → '+Math.round(sim).toLocaleString('pt-BR')+' simulado ('+Math.round(100*(1-sim/Math.max(1,hoje)))+'% menor)').addTo(camadaEsc);}});
document.getElementById('mapaEscTxt').textContent='Faixa '+document.getElementById('faixa').selectedOptions[0].text+' · '+linhas.length+' pontos com coordenada · soma dos piores blocos: hoje '+Math.round(soma).toLocaleString('pt-BR')+' → simulado '+Math.round(somaS).toLocaleString('pt-BR')+' passageiros ('+Math.round(100*(1-somaS/Math.max(1,soma)))+'% menor). Passageiros de cada viagem divididos entre os pontos nomeados da linha (proxy de região, não GPS).';
setTimeout(()=>mapaEsc.invalidateSize(),50);}}catch(e){{document.getElementById('mapaEsc').innerHTML='<p style=padding:20px>⚪ mapa não carregou: '+e+'</p>';}}}}
document.querySelectorAll('#faixa,#frac,#jan,input[name=escMapa]').forEach(e=>e.addEventListener('input',desenhaEsc));
if(location.hash==='#escalonar')setTimeout(desenhaEsc,300);
</script></body></html>"""
if TIME:
    for aba in ('tele',):
        page = re.sub(r'<button data-t=%s>.*?</button>' % aba, '', page, flags=re.S)
        page = re.sub(r'<section class=aba id=%s>.*?</section>' % aba, '', page, flags=re.S)
    page = re.sub(r'<h3>Pendências de segurança e sistema.*?</ul>', '', page, flags=re.S)
    page = re.sub(r'<h3>Coordenação com o Codex</h3>.*?</section>', '</div></section>', page, flags=re.S)
    page = re.sub(r'<h3>Análise completa \(braço de análise.*?</div>', '</div>', page, count=1, flags=re.S)
    page = page.replace('~/.egos/hackathon/ (fora do git)', 'Visão de Rota · painel do time').replace('Prime (Claude, sessão de hoje)', 'IA do time (Claude)')
    page = re.sub(r'<footer>.*?</footer>', '<footer>Painel do time Visão de Rota · Hackathon Cidades Inteligentes, Patos de Minas, 19/09/2026 · gerado a partir de dados públicos e do relatório de viagens entregue ao time · toda seção é proposta para discussão no grupo.</footer>', page, flags=re.S)
    # R-ENTREGA-PURA-001: peça para o time não carrega caminho interno, nome de motor nem menção a dado policial
    subs = [(r'acervo-intelink-bracc\.md', 'regras-de-cruzamento.md'), (r'REDS/PCMG', 'dado policial'), (r'\bREDS\b', 'dado policial'), (r'\bPCMG\b', 'polícia'), (r'\bCodex\b', 'a IA do time'),
            (r'/home/enio/[^\s<>\'"`)]*', '(arquivo do time)'), (r'~/\.egos/[^\s<>\'"`)]*', '(arquivo do time)'), (r'~/enio-dev/[^\s<>\'"`)]*', '(arquivo do time)'),
            (r'enio-dev/[^\s<>\'"`)]*', '(arquivo do time)'), (r'\.egos/[^\s<>\'"`)]*', '(arquivo do time)'), (r'intelink', 'motor de análise'), (r'Eagle Eye', 'radar de licitações'), (r'\bEGOS\b', 'a IA do time')]
    for a, b in subs: page = re.sub(a, b, page)
    page = page.replace('<div class="header-logo">a IA do time <span>', '<div class="header-logo">Visão de Rota <span>')
# ── agrupar as 21 seções em 6 abas (pedido do time 19/09: reduzir, unir)
GRUPOS = {'g-time': ['reza', 'desenho', 'roteiro', 'blocos', 'startup', 'modelo', 'gamif'], 'g-dado': ['onibus', 'unipam'], 'g-mapa': ['mapa', 'escalonar'], 'g-cameras': ['simcam', 'cameras', 'olhovivo', 'legal', 'parcerias'], 'g-fontes': ['fontes', 'editais', 'regras'], 'g-proximos': ['proximos', 'tele']}
secs = dict(re.findall(r'<section class="?aba(?: on)?"? id=(\w+)>(.*?)</section>', page, flags=re.S))
grupos_html = ''
for g, ids in GRUPOS.items():
    partes = [secs[i] for i in ids if i in secs]
    NOMES = {'simcam': 'Simulação: 10 a 600 câmeras', 'reza': 'Afinar a reza', 'desenho': 'Como tudo se liga', 'roteiro': 'Roteiro e pitch', 'blocos': '5 blocos do time', 'startup': 'Que startup é essa', 'modelo': 'Clientes, preço, custos', 'gamif': 'Gamificação', 'onibus': 'Dado do ônibus (agosto)', 'unipam': 'Ônibus da UNIPAM', 'mapa': 'Mapa de calor', 'escalonar': 'Horário escalonado', 'cameras': 'Câmera inteligente + Conecta Patos', 'olhovivo': 'Olho Vivo: quem manda', 'legal': 'Base legal (LGPD)', 'parcerias': 'Onde já acontece (BR + mundo)', 'fontes': 'Fontes: temos / falta / quem tem', 'editais': 'Editais e municípios de referência', 'regras': 'Regras de cruzamento', 'proximos': 'Próximos passos', 'tele': 'Telemetria'}
    def titulo(i): return NOMES.get(i, i)
    sub = ''.join('<a href="#%s">%s</a>' % (i, titulo(i)) for i in ids if i in secs)
    corpo = ''.join(f'<div id="{i}">{secs[i]}</div>' for i in ids if i in secs)
    grupos_html += f'<section class="aba{" on" if g == "g-time" else ""}" id={g}><div class=sub>{sub}</div>{corpo}</section>'
page = re.sub(r'<section class="?aba(?: on)?"? id=\w+>.*?</section>', '', page, flags=re.S)
page = page.replace('</div>\n<footer>', grupos_html + '</div>\n<footer>', 1)
if TIME:
    _restos = [(i, l[max(0, m.start() - 70):m.end() + 50].strip()) for i, l in enumerate(page.split('\n'), 1) for m in [sanear.RESTO_GERAL.search(l)] if m]
    if _restos:
        for i, l in _restos[:40]: print(f'RESTA linha {i}: {l}')
        print(f'[ERRO] versão compartilhada ainda carrega {len(_restos)} linha(s) com referência interna — não gravada'); sys.exit(1)
page = page.replace('</body>', SIMCAM_JS % json.dumps(simcam, ensure_ascii=False).replace('</', '<\\/') + '</body>', 1)
out = H + ('dashboard-time.html' if TIME else 'dashboard.html')
open(out, 'w').write(page)
print(out, len(page), 'bytes ·', len(A), 'A ·', len(B), 'B ·', len(A2), 'A2 ·', len(C), 'C ·', n_geo, 'pontos geo')
