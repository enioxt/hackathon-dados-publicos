# Checklist do pitch — Visão de Rota (para o time votar no grupo)

Banca: domingo 20/09 · 13h30 pré-pitch · 16h prazo de entrega · 17h banca.
Como votar: responda no grupo com os números que você acha mais importantes (ex.: "1, 4, 7") e, se quiser, o seu nome ao lado de uma tarefa. Quem marcar @egos recebe o placar atualizado.

## Por ordem de importância (proposta — o time muda votando)
1. **Definir quem fala os 3 minutos** e quem opera a tela. — sem dono ainda
2. **Ensaiar o pitch em voz alta com cronômetro**, 2 vezes. Roteiro pronto. — sem dono
3. **Confirmar o formato da entrega das 16h** com a organização (link, PDF ou formulário). — sem dono
4. **Preencher o canvas no papel** como o facilitador pediu (temos a versão digital para copiar: 7 dores, 11 funcionalidades, 17 ligações). — sem dono
5. **Pedir à prefeitura 1 hora de vídeo gravado de 1 câmera** (é o nosso pedido nº 1; se vier hoje, vira demonstração real). — sem dono
6. **Confirmar com o diretor o nome da rua** do semáforo que pode sair (veio de gravação, pode estar errado). — sem dono
7. **Decidir o nome final do time** (Visão de Rota foi proposto; método "Segunda Leitura"). — votação
8. **Gerar as imagens da página** com os prompts prontos (14 de imagem e vídeo + 24 de tela). — sem dono
9. **Testar a demonstração no projetor do local** (painel, parede de monitores e apresentação funcionam sem internet; o chat com IA precisa de internet). — Enio
10. **Convidar outros times para o hub de ideias** (hoje só tem as nossas 9). — todos
11. **Mandar o usuário ou e-mail do GitHub** para entrar no repositório do time. — cada um

## O que já está pronto (não precisa de voto)
Apresentação de 12 slides + PDF · roteiro de 3 min com 6 perguntas da banca · canvas digital · painel do gestor · parede de monitores · app do cidadão (10 telas) · calculadora de preço (piloto R$ 49 mil, abaixo do teto de dispensa de R$ 65.492) · hub e demonstração no ar · pesquisa de concorrentes, preços e compras de câmera da cidade.

## Placar de votos
(o agente do grupo atualiza aqui: item → votos → quem assumiu)
