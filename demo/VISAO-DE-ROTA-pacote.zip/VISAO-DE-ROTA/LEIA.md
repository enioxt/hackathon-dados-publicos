# Pasta do hackathon — como está organizada (19/09/2026, 18h40)

| Pasta | O que tem | Para quem |
|---|---|---|
| **1-apresentar/** | apresentação (+PDF), canvas do problema, roteiro do pitch de 5 min, "comece aqui", checklist votável, decisões, índice, prompts de design | vai à banca |
| **2-prototipo/** | painel do gestor e app do cidadão (abra no navegador) | demonstração |
| **3-equipe/** | análise do que falta, fala da prefeitura, atas, índice da sessão, coordenação; `pesquisa/` com concorrentes, preços, APIs, compras de câmera; `transcricoes/` da sala; `commons/` do hub | só o time |
| **4-dados/** | agregados em JSON: acidentes (medidos por nós na base nacional), simulação de câmeras, pontos, editais | máquina |
| **5-motor/** | `simcam.py` (simulação de cobertura), `sanear-publico.py` (tira referência interna antes de publicar), `build-dashboard.py` | máquina |
| **cco/** | servidor local do centro de controle (`bun servidor.ts`), parede de monitores, calculadora, mapa offline | roda em 127.0.0.1:8787 |
| **publico/** | o repositório público (GitHub Pages) — `demo/`, `hub/`, `dados/`, `fontes/` | no ar |
| **repo/** | o repositório privado do time | convite necessário |
| **fontes/** | bases públicas baixadas (561 MB, re-baixáveis; hashes no MANIFEST) | não vai ao git |
| **gravacao/** | áudio da sala (287 MB) e as transcrições em `txt/` | áudio não vai ao git |
| **_arquivo/** | prints e versões antigas | histórico |

**Começar por:** `1-apresentar/COMECE-AQUI.html`.
